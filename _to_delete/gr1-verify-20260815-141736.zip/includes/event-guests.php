<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('pge_event_guests_norm_phone')) {
    function pge_event_guests_norm_phone($value)
    {
        return preg_replace('/\D+/', '', trim((string) $value));
    }
}

if (!function_exists('pge_event_guests_resolve_current_by_phone')) {
    /**
     * Resolve one current invited-guest identity without exposing guest data.
     *
     * This intentionally inspects the raw guest records. The normal map cannot
     * prove uniqueness because canonical phone keys collapse duplicates.
     */
    function pge_event_guests_resolve_current_by_phone($event_id, $guest_phone)
    {
        if (!is_int($event_id) || $event_id <= 0 || !is_string($guest_phone)) {
            return ['status' => 'storage_error'];
        }

        $canonical = pge_event_guests_norm_phone($guest_phone);
        if (!is_string($canonical) || $canonical === '') {
            return ['status' => 'storage_error'];
        }

        $stored = get_post_meta($event_id, '_pge_invited_guests', true);
        if ($stored === '' || $stored === null || $stored === false || $stored === []) {
            return ['status' => 'not_found'];
        }
        if (!is_array($stored)) {
            return ['status' => 'storage_error'];
        }

        $matches = 0;
        foreach ($stored as $guest) {
            if (!is_array($guest) || !array_key_exists('phone', $guest) || !is_string($guest['phone'])) {
                return ['status' => 'storage_error'];
            }
            $phone = pge_event_guests_norm_phone($guest['phone']);
            if (!is_string($phone) || $phone === '') {
                return ['status' => 'storage_error'];
            }
            if ($phone === $canonical) {
                $matches++;
                if ($matches > 1) return ['status' => 'ambiguous'];
            }
        }

        return ['status' => $matches === 1 ? 'found' : 'not_found'];
    }
}

if (!function_exists('pge_event_guests_user_can_manage')) {
    function pge_event_guests_user_can_manage($event_id)
    {
        $event_id = (int) $event_id;
        if ($event_id <= 0 || get_post_type($event_id) !== 'pge_event') return false;

        $uid = get_current_user_id();
        $author_id = (int) get_post_field('post_author', $event_id);

        if (current_user_can('administrator')) return true;
        if ($uid && $uid === $author_id) return true;
        if (current_user_can('edit_post', $event_id)) return true;

        return false;
    }
}

if (!function_exists('pge_event_guests_parse_phones_meta')) {
    function pge_event_guests_parse_phones_meta($event_id)
    {
        $raw = get_post_meta($event_id, '_pge_invited_phones', true);

        if (is_array($raw)) {
            $phones = $raw;
        } else {
            $raw = (string) $raw;
            $raw = str_replace(["\r\n", "\r"], "\n", $raw);
            $phones = array_filter(array_map('trim', explode("\n", $raw)));
        }

        $out = [];
        foreach ($phones as $phone) {
            $norm = pge_event_guests_norm_phone($phone);
            if ($norm !== '') $out[$norm] = $norm;
        }

        return array_values($out);
    }
}

if (!function_exists('pge_event_guests_get_map')) {
    function pge_event_guests_get_map($event_id)
    {
        $event_id = (int) $event_id;
        $stored = get_post_meta($event_id, '_pge_invited_guests', true);
        $map = [];

        if (is_array($stored)) {
            foreach ($stored as $key => $guest) {
                if (!is_array($guest)) {
                    $phone = pge_event_guests_norm_phone(is_string($guest) ? $guest : $key);
                    if ($phone === '') continue;
                    $map[$phone] = [
                        'phone' => $phone,
                        'name'  => '',
                        'note'  => '',
                        'code'  => '',
                    ];
                    continue;
                }

                $phone = pge_event_guests_norm_phone($guest['phone'] ?? $key);
                if ($phone === '') continue;

                $map[$phone] = [
                    'phone' => $phone,
                    'name'  => sanitize_text_field((string) ($guest['name'] ?? '')),
                    'note'  => sanitize_textarea_field((string) ($guest['note'] ?? '')),
                    'code'  => sanitize_text_field((string) ($guest['code'] ?? '')),
                ];
            }
        }

        if (empty($map)) {
            $legacy_phones = pge_event_guests_parse_phones_meta($event_id);
            foreach ($legacy_phones as $phone) {
                $map[$phone] = [
                    'phone' => $phone,
                    'name'  => '',
                    'note'  => '',
                    'code'  => '',
                ];
            }
        }

        return $map;
    }
}

if (!function_exists('pge_event_guests_save_map')) {
    function pge_event_guests_save_map($event_id, $map)
    {
        $event_id = (int) $event_id;
        $clean = [];

        foreach ((array) $map as $guest) {
            if (!is_array($guest)) continue;

            $phone = pge_event_guests_norm_phone($guest['phone'] ?? '');
            if ($phone === '') continue;

            // توليد رمز شخصي إذا لم يكن موجوداً
            $code = sanitize_text_field((string) ($guest['code'] ?? ''));
            if ($code === '' || !preg_match('/^[A-Z0-9]{4}-[A-Z0-9]{4}$/', $code)) {
                $code = function_exists('pge_generate_invite_code')
                    ? pge_generate_invite_code()
                    : strtoupper(substr(str_replace(['+','/','='],'',base64_encode(random_bytes(6))), 0, 4))
                      . '-'
                      . strtoupper(substr(str_replace(['+','/','='],'',base64_encode(random_bytes(6))), 0, 4));
            }

            $clean[$phone] = [
                'phone' => $phone,
                'name'  => sanitize_text_field((string) ($guest['name'] ?? '')),
                'note'  => sanitize_textarea_field((string) ($guest['note'] ?? '')),
                'code'  => $code,
            ];
        }

        update_post_meta($event_id, '_pge_invited_guests', $clean);
        update_post_meta($event_id, '_pge_invited_phones', array_keys($clean));

        return $clean;
    }
}

if (!function_exists('pge_event_guests_get_status_label')) {
    function pge_event_guests_get_status_label($status)
    {
        if ($status === 'yes') return 'سيحضر';
        if ($status === 'no') return 'اعتذر';
        return 'لم يرد';
    }
}

/**
 * جلب بيانات RSVP من الجدول الحقيقي لمناسبة معينة
 * يُعيد: map (phone=>reply) + checkin_map (phone=>true) +
 * integrity_errors (phone=>true). الهوية المكررة لا تختار أول/آخر صف.
 * يُخزَّن في static cache لتجنب الاستعلام المتكرر في نفس الطلب
 */
if (!function_exists('pge_event_guests_load_rsvp_from_db')) {
    function pge_event_guests_load_rsvp_from_db(int $event_id): array
    {
        static $cache = [];
        if (isset($cache[$event_id])) return $cache[$event_id];

        global $wpdb;
        $table = $wpdb->prefix . 'pge_event_rsvps';
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT guest_phone, reply, checked_in FROM {$table} WHERE event_id = %d",
            $event_id
        ), ARRAY_A);

        $map = [];
        $checkin_map = [];
        $integrity_errors = [];
        $seen_phones = [];
        foreach ((array) $rows as $r) {
            $phone = function_exists('pge_norm_phone')
                ? pge_norm_phone($r['guest_phone'] ?? '')
                : preg_replace('/\D+/', '', (string) ($r['guest_phone'] ?? ''));
            if ($phone === '') {
                continue;
            }
            if (isset($seen_phones[$phone])) {
                $integrity_errors[$phone] = true;
                unset($map[$phone], $checkin_map[$phone]);
                continue;
            }
            $seen_phones[$phone] = true;
            if (isset($integrity_errors[$phone])) {
                continue;
            }
            $map[$phone] = $r['reply'];
            if ((int) $r['checked_in'] === 1) {
                $checkin_map[$phone] = true;
            }
        }

        $cache[$event_id] = compact('map', 'checkin_map', 'integrity_errors');
        return $cache[$event_id];
    }
}

if (!function_exists('pge_event_guests_get_row_payload')) {
    function pge_event_guests_get_row_payload($event_id, $guest)
    {
        $phone = pge_event_guests_norm_phone($guest['phone'] ?? '');
        $name  = sanitize_text_field((string) ($guest['name'] ?? ''));
        $note  = sanitize_textarea_field((string) ($guest['note'] ?? ''));

        $rsvp   = pge_event_guests_load_rsvp_from_db((int) $event_id);
        $reply  = isset($rsvp['map'][$phone]) ? (string) $rsvp['map'][$phone] : '';
        $status = ($reply === 'yes' || $reply === 'no') ? $reply : 'pending';
        $checked = isset($rsvp['checkin_map'][$phone]) ? 'yes' : 'no';

        $code = sanitize_text_field((string) ($guest['code'] ?? ''));

        return [
            'phone'        => $phone,
            'name'         => $name,
            'note'         => $note,
            'code'         => $code,
            'status'       => $status,
            'status_label' => pge_event_guests_get_status_label($status),
            'checked'      => $checked,
        ];
    }
}

if (!function_exists('pge_event_guests_get_stats')) {
    function pge_event_guests_get_stats($event_id, $guests_map = null)
    {
        if (!is_array($guests_map)) {
            $guests_map = pge_event_guests_get_map($event_id);
        }

        $phones = array_keys($guests_map);
        $total  = count($phones);
        $yes = $no = $checked = 0;

        $rsvp = pge_event_guests_load_rsvp_from_db((int) $event_id);

        foreach ($phones as $phone) {
            $reply = $rsvp['map'][$phone] ?? '';
            if ($reply === 'yes') $yes++;
            if ($reply === 'no')  $no++;
            if (isset($rsvp['checkin_map'][$phone])) $checked++;
        }

        $pending = max(0, $total - ($yes + $no));

        return [
            'total'   => $total,
            'yes'     => $yes,
            'no'      => $no,
            'pending' => $pending,
            'checked' => $checked,
        ];
    }
}

if (!function_exists('pge_event_guests_validate_request')) {
    function pge_event_guests_validate_request()
    {
        if (!is_user_logged_in()) {
            wp_send_json_error('غير مصرح');
        }

        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!$nonce || !wp_verify_nonce($nonce, 'pge_event_manage_nonce')) {
            wp_send_json_error('رمز الأمان غير صالح');
        }

        $event_id = isset($_POST['event_id']) ? (int) $_POST['event_id'] : 0;
        if (!$event_id || get_post_type($event_id) !== 'pge_event') {
            wp_send_json_error('مناسبة غير صالحة');
        }

        if (!pge_event_guests_user_can_manage($event_id)) {
            wp_send_json_error('ليس لديك صلاحية إدارة هذه المناسبة');
        }

        return $event_id;
    }
}

if (!function_exists('pge_event_guests_migrate_phone_refs')) {
    function pge_event_guests_migrate_phone_refs($event_id, $old_phone, $new_phone)
    {
        if ($old_phone === $new_phone || $old_phone === '' || $new_phone === '') return;

        $rsvp_map = (array) get_post_meta($event_id, '_pge_rsvp_map', true);
        if (isset($rsvp_map[$old_phone])) {
            if (!isset($rsvp_map[$new_phone])) {
                $rsvp_map[$new_phone] = $rsvp_map[$old_phone];
            }
            unset($rsvp_map[$old_phone]);
            update_post_meta($event_id, '_pge_rsvp_map', $rsvp_map);
        }

        $checkins = (array) get_post_meta($event_id, '_pge_checkins', true);
        if (isset($checkins[$old_phone])) {
            if (!isset($checkins[$new_phone])) {
                $checkins[$new_phone] = $checkins[$old_phone];
            }
            unset($checkins[$old_phone]);
            update_post_meta($event_id, '_pge_checkins', $checkins);
        }
    }
}

if (!function_exists('pge_event_guests_remove_phone_refs')) {
    function pge_event_guests_remove_phone_refs($event_id, $phone)
    {
        if ($phone === '') return;

        $rsvp_map = (array) get_post_meta($event_id, '_pge_rsvp_map', true);
        if (isset($rsvp_map[$phone])) {
            unset($rsvp_map[$phone]);
            update_post_meta($event_id, '_pge_rsvp_map', $rsvp_map);
        }

        $checkins = (array) get_post_meta($event_id, '_pge_checkins', true);
        if (isset($checkins[$phone])) {
            unset($checkins[$phone]);
            update_post_meta($event_id, '_pge_checkins', $checkins);
        }
    }
}

/**
 * ============================================================================
 * Guest Limit Unification RFC — Part A: Legacy Creation Endpoint Retirement
 * ============================================================================
 * `wp_ajax_pge_event_guest_add` و`wp_ajax_pge_event_guest_bulk_add` كانتا
 * مسجَّلتين هنا وتكتبان مباشرة عبر pge_event_guests_get_map()/save_map()،
 * **بلا مرور إطلاقاً** عبر PGE_Invitation_Service/Repository/Audit — أي بلا
 * أي وعي بحصة المدعوين (guest_limit)، وبلا تدقيق. هذا كان الثغرة الوحيدة
 * التي تسمح بتجاوز حصة المدعوين حتى بعد توحيد الإنفاذ في
 * PGE_Invitation_Service::create() (راجع docs/INVITATION-GUEST-LIMIT-
 * ENFORCEMENT.md).
 *
 * دليل عدم الاستخدام قبل الإزالة (لا افتراض):
 *   - RC1 Fix Pack 3B (docs/RC1-AUDIT.md §16.4) أزال بالفعل كل نماذج/أزرار
 *     الواجهة القديمة (`addGuestForm`/`bulkGuestForm`) من page-event-
 *     manage.php — لا عنصر DOM يستدعي هذين الإجرائين بعد الآن (مُتحقَّق
 *     تنفيذياً في tests/test-rc1-fixpack2.php A4.8/A4.9 وtest-rc1-
 *     fixpack3b.php).
 *   - RC1 Fix Pack 3A (§15) نقل الإضافة الجماعية بالكامل إلى
 *     PGE_Invitation_Bulk_Add_Service — لا فجوة وظيفية متبقّية تبرّر إبقاء
 *     `pge_event_guest_bulk_add` حياً.
 *   - بحث شامل في كامل wp-content (PHP + JS + قوالب) عن استدعاء فعلي لهذين
 *     الإجراءين عبر admin-ajax.php لم يُظهر أي مستدعٍ حي سوى الاختبارات
 *     والتوثيق التاريخي.
 *
 * القرار: إزالة تسجيل الإجراءين (`add_action`) فقط — لم تُحذف أي دالة
 * مساعدة (pge_event_guests_get_map/save_map/validate_request/...)، ولم
 * يُلمَس `pge_event_guest_update`/`_delete`/`_bulk_delete`/`_regen_code` أو
 * أي كود QR/قراءة أدناه في هذا الملف إطلاقاً. لم تعد هاتان الدالتان قابلتين
 * للاستدعاء عبر admin-ajax.php بعد الآن.
 */



add_action('wp_ajax_pge_event_guest_update', function () {
    $event_id = pge_event_guests_validate_request();

    $old_phone = pge_event_guests_norm_phone($_POST['old_phone'] ?? '');
    $new_phone = pge_event_guests_norm_phone($_POST['phone'] ?? '');
    $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
    $note = isset($_POST['note']) ? sanitize_textarea_field(wp_unslash($_POST['note'])) : '';

    if ($old_phone === '' || $new_phone === '') {
        wp_send_json_error('بيانات المدعو غير مكتملة');
    }

    // Phase D2: keep this registered legacy compatibility endpoint, but route
    // all writes through the authoritative Service so phone changes cannot
    // bypass target RSVP reset, QR rotation, compensation, or audit.
    if (!class_exists('PGE_Invitation_Service')) {
        require_once __DIR__ . '/class-pge-invitation-service.php';
    }
    $result = PGE_Invitation_Service::edit(
        $event_id,
        $old_phone,
        $new_phone,
        $name,
        $note,
        get_current_user_id()
    );

    if (($result['result'] ?? '') === 'duplicate') {
        wp_send_json_error('رقم الجوال الجديد مستخدم بالفعل');
    }
    if (($result['result'] ?? '') === 'error' && ($result['reason'] ?? '') === 'not_found') {
        wp_send_json_error('المدعو غير موجود');
    }
    if (($result['result'] ?? '') !== 'updated') {
        wp_send_json_error('تعذّر تحديث بيانات المدعو');
    }

    $guests_map = pge_event_guests_get_map($event_id);

    wp_send_json_success([
        'message' => 'تم تحديث بيانات المدعو',
        'guest'   => pge_event_guests_get_row_payload($event_id, $guests_map[$new_phone]),
        'stats'   => pge_event_guests_get_stats($event_id, $guests_map),
    ]);
});

/**
 * ============================================================================
 * RC1 Fix Pack 3B — "Legacy Guest Panel Retirement (Hard Delete Migration)"
 * ============================================================================
 * "If deletion currently bypasses the Invitation Service, refactor by moving
 * deletion into the Service. Do NOT duplicate delete logic." — هذا المعالج
 * القديم كان يُنفِّذ الحذف مباشرة (unset + remove_phone_refs + save_map) بلا
 * مرور بأي طبقة خدمة. أصبح الآن يُفوِّض بالكامل لـPGE_Invitation_Service::
 * delete() (التي تُعيد استخدام **نفس** الخطوات الثلاث حرفياً داخل
 * PGE_Invitation_Repository::delete() — راجع توثيقها الكامل هناك)، فيصبح
 * هناك نقطة تنفيذ حذف واحدة فقط في كامل المشروع. **لا تغيير في السلوك
 * الملحوظ من طرف العميل** (نفس رسائل النجاح/الفشل، نفس بنية 'stats' في
 * الاستجابة) — فقط إزالة الازدواجية الداخلية. هذا المعالج **لم يعد له أي
 * زر مُشغِّل في الواجهة** بعد تفكيك لوحة المدعوين القديمة (page-event-
 * manage.php) — يبقى مُسجَّلاً فعلياً (Legacy AJAX handlers may remain
 * registered) كطبقة توافق فقط، ويستمر بتطبيق نفس فحوصات التفويض/nonce/
 * ملكية المناسبة كاملة عبر pge_event_guests_validate_request() أعلاه.
 */
add_action('wp_ajax_pge_event_guest_delete', function () {
    $event_id = pge_event_guests_validate_request();
    $phone = pge_event_guests_norm_phone($_POST['phone'] ?? '');

    if ($phone === '') {
        wp_send_json_error('رقم الجوال غير صالح');
    }

    if (!class_exists('PGE_Invitation_Service')) {
        wp_send_json_error('تعذّر تنفيذ العملية');
    }

    $result = PGE_Invitation_Service::delete($event_id, $phone, get_current_user_id());
    if (($result['result'] ?? '') !== 'deleted') {
        wp_send_json_error('المدعو غير موجود');
    }

    wp_send_json_success([
        'message' => 'تم حذف المدعو',
        'stats'   => pge_event_guests_get_stats($event_id),
    ]);
});

// ── حفظ قوالب رسائل واتساب للمناسبة ────────────────────────────────────────
add_action('wp_ajax_pge_event_save_wa_templates', function () {
    $event_id = pge_event_guests_validate_request();

    $keys = ['invite', 'yes', 'no', 'invalid'];
    foreach ($keys as $k) {
        $val = sanitize_textarea_field(wp_unslash($_POST['tpl_' . $k] ?? ''));
        if ($val !== '') {
            update_post_meta($event_id, '_pge_wa_tpl_' . $k, $val);
        } else {
            delete_post_meta($event_id, '_pge_wa_tpl_' . $k); // حذف = استخدام الافتراضي
        }
    }

    wp_send_json_success(['message' => '✅ تم حفظ قوالب الرسائل']);
});

// ── تجديد رمز ضيف معيّن ─────────────────────────────────────────────────────
add_action('wp_ajax_pge_event_guest_regen_code', function () {
    $event_id = pge_event_guests_validate_request();
    $phone = pge_event_guests_norm_phone($_POST['phone'] ?? '');

    if ($phone === '') {
        wp_send_json_error('رقم الجوال غير صالح');
    }

    $guests_map = pge_event_guests_get_map($event_id);
    if (!isset($guests_map[$phone])) {
        wp_send_json_error('المدعو غير موجود');
    }

    $new_code = function_exists('pge_generate_invite_code')
        ? pge_generate_invite_code()
        : strtoupper(substr(str_replace(['+','/','='],'',base64_encode(random_bytes(6))), 0, 4))
          . '-'
          . strtoupper(substr(str_replace(['+','/','='],'',base64_encode(random_bytes(6))), 0, 4));

    $guests_map[$phone]['code'] = $new_code;
    pge_event_guests_save_map($event_id, $guests_map);

    wp_send_json_success([
        'message' => 'تم توليد رمز جديد',
        'phone'   => $phone,
        'code'    => $new_code,
    ]);
});

/**
 * RC1 Fix Pack 3B — نفس التفويض/عدم-تكرار-منطق-الحذف الموثَّق أعلى المعالج
 * المفرد مباشرة. "Reuse the same deletion path repeatedly. Do not create a
 * second delete algorithm." — حلقة تستدعي PGE_Invitation_Service::delete()
 * مرة لكل هاتف، تماماً كما يفعل معالج الحذف الجماعي في الإضافة الجديدة
 * (pge_invitation_mgmt_bulk_delete_handler) — **نفس** الدالة الأساسية،
 * مُستدعاة من نقطتين مختلفتين فقط، لا نسخة ثانية من منطق الحذف نفسه.
 */
add_action('wp_ajax_pge_event_guest_bulk_delete', function () {
    $event_id = pge_event_guests_validate_request();

    $phones_raw = $_POST['phones'] ?? '';
    if (is_array($phones_raw)) {
        $candidates = $phones_raw;
    } else {
        $candidates = preg_split('/[\s,]+/', (string) $phones_raw);
    }

    $phones = [];
    foreach ((array) $candidates as $candidate) {
        $phone = pge_event_guests_norm_phone($candidate);
        if ($phone !== '') $phones[$phone] = $phone;
    }
    $phones = array_values($phones);

    if (empty($phones)) {
        wp_send_json_error('اختر مدعوين للحذف');
    }

    if (!class_exists('PGE_Invitation_Service')) {
        wp_send_json_error('تعذّر تنفيذ العملية');
    }

    $actor_user_id = get_current_user_id();
    $deleted = 0;
    foreach ($phones as $phone) {
        $result = PGE_Invitation_Service::delete($event_id, $phone, $actor_user_id);
        if (($result['result'] ?? '') === 'deleted') {
            $deleted++;
        }
    }

    wp_send_json_success([
        'message' => sprintf('تم حذف %d مدعو.', $deleted),
        'deleted' => $deleted,
        'stats'   => pge_event_guests_get_stats($event_id),
    ]);
});

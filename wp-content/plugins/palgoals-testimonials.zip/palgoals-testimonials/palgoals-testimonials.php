<?php
/**
 * Plugin Name: Palgoals Testimonials Manager
 * Plugin URI: https://palgoals.com/
 * Description: Manage customer testimonials from the WordPress dashboard and display them through Elementor widgets or shortcodes.
 * Version: 1.0.0
 * Author: Palgoals Information Technology
 * Author URI: https://palgoals.com/
 * Text Domain: palgoals-testimonials
 * Domain Path: /languages
 *
 * @package PalgoalsTestimonials
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PALGOALS_TESTIMONIALS_VERSION', '1.0.0' );
define( 'PALGOALS_TESTIMONIALS_FILE', __FILE__ );
define( 'PALGOALS_TESTIMONIALS_PATH', plugin_dir_path( __FILE__ ) );
define( 'PALGOALS_TESTIMONIALS_URL', plugin_dir_url( __FILE__ ) );

require_once PALGOALS_TESTIMONIALS_PATH . 'includes/class-cpt.php';
require_once PALGOALS_TESTIMONIALS_PATH . 'includes/class-renderer.php';
require_once PALGOALS_TESTIMONIALS_PATH . 'includes/class-screenshots-renderer.php';
require_once PALGOALS_TESTIMONIALS_PATH . 'includes/class-admin.php';
require_once PALGOALS_TESTIMONIALS_PATH . 'includes/class-shortcode.php';
require_once PALGOALS_TESTIMONIALS_PATH . 'includes/class-elementor.php';

final class Palgoals_Testimonials_Manager {

	/**
	 * Singleton instance.
	 *
	 * @var Palgoals_Testimonials_Manager|null
	 */
	private static $instance = null;

	/**
	 * CPT manager.
	 *
	 * @var Palgoals_Testimonials_CPT
	 */
	private $cpt;

	/**
	 * Admin manager.
	 *
	 * @var Palgoals_Testimonials_Admin
	 */
	private $admin;

	/**
	 * Shortcode manager.
	 *
	 * @var Palgoals_Testimonials_Shortcode
	 */
	private $shortcode;

	/**
	 * Elementor manager.
	 *
	 * @var Palgoals_Testimonials_Elementor
	 */
	private $elementor;

	/**
	 * Return the singleton instance.
	 *
	 * @return Palgoals_Testimonials_Manager
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Wire plugin services.
	 */
	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		$this->cpt       = new Palgoals_Testimonials_CPT();
		$this->admin     = new Palgoals_Testimonials_Admin();
		$this->shortcode = new Palgoals_Testimonials_Shortcode();
		$this->elementor = new Palgoals_Testimonials_Elementor();

		$this->cpt->register();
		$this->admin->register();
		$this->shortcode->register();
		$this->elementor->register();

		Palgoals_Testimonials_Renderer::register();

		add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 2 );
	}

	/**
	 * Load translations.
	 *
	 * @return void
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			'palgoals-testimonials',
			false,
			dirname( plugin_basename( PALGOALS_TESTIMONIALS_FILE ) ) . '/languages'
		);
	}

	/**
	 * Add branded plugin meta.
	 *
	 * @param string[] $links Existing links.
	 * @param string   $file  Plugin file.
	 * @return string[]
	 */
	public function plugin_row_meta( $links, $file ) {
		if ( plugin_basename( PALGOALS_TESTIMONIALS_FILE ) !== $file ) {
			return $links;
		}

		$links[] = '<span>' . esc_html__( 'Developed by Palgoals Information Technology', 'palgoals-testimonials' ) . '</span>';

		return $links;
	}

	/**
	 * Activation callback.
	 *
	 * @return void
	 */
	public static function activate() {
		$cpt = new Palgoals_Testimonials_CPT();
		$cpt->register_post_type();
		$cpt->register_post_meta();
		flush_rewrite_rules();
	}

	/**
	 * Deactivation callback.
	 *
	 * @return void
	 */
	public static function deactivate() {
		flush_rewrite_rules();
	}
}

register_activation_hook( PALGOALS_TESTIMONIALS_FILE, array( 'Palgoals_Testimonials_Manager', 'activate' ) );
register_deactivation_hook( PALGOALS_TESTIMONIALS_FILE, array( 'Palgoals_Testimonials_Manager', 'deactivate' ) );

/**
 * Bootstrap the plugin.
 *
 * @return Palgoals_Testimonials_Manager
 */
function palgoals_testimonials_manager() {
	return Palgoals_Testimonials_Manager::instance();
}

palgoals_testimonials_manager();

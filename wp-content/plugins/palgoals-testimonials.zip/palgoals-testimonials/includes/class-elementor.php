<?php
/**
 * Elementor integration.
 *
 * @package PalgoalsTestimonials
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Palgoals_Testimonials_Elementor {

	/**
	 * Prevent duplicate registration across Elementor versions.
	 *
	 * @var array
	 */
	protected $registered_widgets = array();

	/**
	 * Register Elementor hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_category' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widget' ) );
		add_action( 'elementor/widgets/widgets_registered', array( $this, 'register_legacy_widget' ) );
	}

	/**
	 * Add a Palgoals widget category.
	 *
	 * @param object $elements_manager Elementor category manager.
	 * @return void
	 */
	public function register_category( $elements_manager ) {
		if ( ! method_exists( $elements_manager, 'add_category' ) ) {
			return;
		}

		$elements_manager->add_category(
			'palgoals-elements',
			array(
				'title' => __( 'Palgoals', 'palgoals-testimonials' ),
				'icon'  => 'fa fa-plug',
			)
		);
	}

	/**
	 * Register widget for modern Elementor versions.
	 *
	 * @param object $widgets_manager Elementor widgets manager.
	 * @return void
	 */
	public function register_widget( $widgets_manager ) {
		if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}

		if ( ! method_exists( $widgets_manager, 'register' ) ) {
			return;
		}

		foreach ( $this->get_widget_definitions() as $class_name => $file ) {
			$this->load_widget_class( $class_name, $file );

			if ( isset( $this->registered_widgets[ $class_name ] ) ) {
				continue;
			}

			$widgets_manager->register( new $class_name() );
			$this->registered_widgets[ $class_name ] = true;
		}
	}

	/**
	 * Register widget for older Elementor versions.
	 *
	 * @return void
	 */
	public function register_legacy_widget() {
		if ( ! class_exists( '\Elementor\Plugin' ) || ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}

		$plugin = \Elementor\Plugin::instance();

		if ( ! isset( $plugin->widgets_manager ) || ! method_exists( $plugin->widgets_manager, 'register_widget_type' ) ) {
			return;
		}

		foreach ( $this->get_widget_definitions() as $class_name => $file ) {
			$this->load_widget_class( $class_name, $file );

			if ( isset( $this->registered_widgets[ $class_name ] ) ) {
				continue;
			}

			$plugin->widgets_manager->register_widget_type( new $class_name() );
			$this->registered_widgets[ $class_name ] = true;
		}
	}

	/**
	 * Return all widget classes and files managed by the plugin.
	 *
	 * @return array
	 */
	protected function get_widget_definitions() {
		return array(
			'Palgoals_Testimonials_Widget'    => 'elementor/class-widget-testimonials.php',
			'Palgoals_Chat_Screenshots_Widget' => 'elementor/class-widget-chat-screenshots.php',
		);
	}

	/**
	 * Load a widget class file when needed.
	 *
	 * @param string $class_name Widget class name.
	 * @param string $file       Relative file path.
	 * @return void
	 */
	protected function load_widget_class( $class_name, $file ) {
		if ( class_exists( $class_name ) ) {
			return;
		}

		require_once PALGOALS_TESTIMONIALS_PATH . $file;
	}
}

<?php
if (!defined('ABSPATH')) exit;

/**
 * Salla Customer Groups API transport.
 *
 * This service is intentionally independent from package activation flows.
 */
class PGE_Salla_Customer_Groups_Service
{
    private const ADD_CUSTOMERS_ENDPOINT = 'https://api.salla.dev/admin/v2/customers/groups/add_customers';

    /**
     * Add one Salla customer to a customer group.
     *
     * @return array|WP_Error
     */
    public function add_customer_to_group($merchant_id, $customer_id, $group_id)
    {
        $merchant_id = $this->positive_integer($merchant_id);
        if ($merchant_id === 0) {
            return new WP_Error('invalid_salla_merchant_id', 'Salla merchant ID must be a positive integer.');
        }

        $customer_id = $this->positive_integer($customer_id);
        if ($customer_id === 0) {
            return new WP_Error('invalid_salla_customer_id', 'Salla customer ID must be a positive integer.');
        }

        $group_id = $this->positive_integer($group_id);
        if ($group_id === 0) {
            return new WP_Error('invalid_salla_group_id', 'Salla customer group ID must be a positive integer.');
        }

        $token_data = get_option('pge_salla_tokens_' . $merchant_id, null);
        if ($token_data === null) {
            return new WP_Error('salla_tokens_missing', 'Salla token data was not found for this merchant.');
        }

        if (!is_array($token_data)) {
            return new WP_Error('salla_token_data_invalid', 'Stored Salla token data is invalid.');
        }

        if (!array_key_exists('access_token', $token_data) || $token_data['access_token'] === '') {
            return new WP_Error('salla_access_token_missing', 'Salla access token is missing.');
        }

        if (!is_string($token_data['access_token'])) {
            return new WP_Error('salla_token_data_invalid', 'Stored Salla access token is invalid.');
        }

        $access_token = trim($token_data['access_token']);
        if ($access_token === '') {
            return new WP_Error('salla_access_token_missing', 'Salla access token is missing.');
        }

        $request_body = wp_json_encode([
            'group_id'  => $group_id,
            'customers' => [$customer_id],
        ]);
        if (!is_string($request_body) || $request_body === '') {
            return new WP_Error('salla_request_encoding_failed', 'Unable to encode the Salla request body.');
        }

        $response = wp_remote_post(self::ADD_CUSTOMERS_ENDPOINT, [
            'headers' => [
                'Authorization' => 'Bearer ' . $access_token,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'body'    => $request_body,
            'timeout' => 20,
        ]);

        if (is_wp_error($response)) {
            return new WP_Error(
                'salla_customer_group_transport_error',
                'Salla customer group request failed.',
                ['cause' => $response->get_error_code()]
            );
        }

        $http_status = (int) wp_remote_retrieve_response_code($response);
        if ($http_status < 200 || $http_status >= 300) {
            return new WP_Error(
                'salla_customer_group_http_error',
                'Salla customer group request returned a non-success HTTP status.',
                ['http_status' => $http_status]
            );
        }

        $response_body = wp_remote_retrieve_body($response);
        if (!is_string($response_body) || trim($response_body) === '') {
            return new WP_Error(
                'salla_customer_group_empty_response',
                'Salla customer group request returned an empty response.',
                ['http_status' => $http_status]
            );
        }

        $decoded = json_decode($response_body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error(
                'salla_customer_group_invalid_json',
                'Salla customer group response was not valid JSON.',
                ['http_status' => $http_status]
            );
        }

        if (!is_array($decoded)) {
            return new WP_Error(
                'salla_customer_group_invalid_response',
                'Salla customer group response has an invalid structure.',
                ['http_status' => $http_status]
            );
        }

        $api_status = $http_status;
        if (array_key_exists('status', $decoded)) {
            $api_status = $this->positive_integer($decoded['status']);
            if ($api_status === 0) {
                return new WP_Error(
                    'salla_customer_group_invalid_response',
                    'Salla customer group response has an invalid status.',
                    ['http_status' => $http_status]
                );
            }
        }

        if (($decoded['success'] ?? null) !== true || $api_status < 200 || $api_status >= 300) {
            return new WP_Error(
                'salla_customer_group_api_error',
                'Salla API did not confirm that the customer was added to the group.',
                [
                    'http_status' => $http_status,
                    'api_status'  => $api_status,
                ]
            );
        }

        return [
            'success'     => true,
            'http_status' => $http_status,
            'api_status'  => $api_status,
            'data'        => $decoded['data'] ?? null,
        ];
    }

    private function positive_integer($value)
    {
        if (!is_scalar($value) || is_bool($value)) {
            return 0;
        }

        $value = filter_var($value, FILTER_VALIDATE_INT, [
            'options' => ['min_range' => 1],
        ]);

        return $value === false ? 0 : (int) $value;
    }
}

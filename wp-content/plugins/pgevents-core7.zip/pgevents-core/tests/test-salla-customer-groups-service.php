<?php
/**
 * Executable unit test for PGE_Salla_Customer_Groups_Service.
 *
 * wp_remote_post() is fully stubbed below, so this test cannot contact Salla.
 * Run: php tests/test-salla-customer-groups-service.php
 */

define('ABSPATH', __DIR__ . '/');

if (!class_exists('WP_Error')) {
    class WP_Error
    {
        private $code;
        private $message;
        private $data;

        public function __construct($code = '', $message = '', $data = null)
        {
            $this->code = $code;
            $this->message = $message;
            $this->data = $data;
        }

        public function get_error_code() { return $this->code; }
        public function get_error_message() { return $this->message; }
        public function get_error_data() { return $this->data; }
    }
}

function is_wp_error($value) { return $value instanceof WP_Error; }
function wp_json_encode($value) { return json_encode($value); }

$GLOBALS['salla_test_options'] = [];
$GLOBALS['salla_test_http_calls'] = [];
$GLOBALS['salla_test_http_response'] = null;

function get_option($name, $default = false)
{
    return array_key_exists($name, $GLOBALS['salla_test_options'])
        ? $GLOBALS['salla_test_options'][$name]
        : $default;
}

function wp_remote_post($url, $args = [])
{
    $GLOBALS['salla_test_http_calls'][] = [
        'url'  => $url,
        'args' => $args,
    ];
    return $GLOBALS['salla_test_http_response'];
}

function wp_remote_retrieve_response_code($response)
{
    return is_array($response) ? (int) ($response['response']['code'] ?? 0) : 0;
}

function wp_remote_retrieve_body($response)
{
    return is_array($response) ? ($response['body'] ?? '') : '';
}

function reset_salla_test_state()
{
    $GLOBALS['salla_test_options'] = [
        'pge_salla_tokens_123' => [
            'access_token'  => 'test-access-token',
            'refresh_token' => 'test-refresh-token',
            'expires'       => 2000000000,
            'scope'         => 'customers.read_write',
            'token_type'    => 'bearer',
            'updated_at'    => '2026-09-15 00:00:00',
        ],
    ];
    $GLOBALS['salla_test_http_calls'] = [];
    $GLOBALS['salla_test_http_response'] = [
        'response' => ['code' => 200],
        'body'     => json_encode([
            'status'  => 200,
            'success' => true,
            'data'    => ['The customers has been added to group successfully'],
        ]),
    ];
}

$failures = 0;

function check($label, $actual, $expected)
{
    global $failures;
    if ($actual === $expected) {
        echo "PASS  $label\n";
        return;
    }

    $failures++;
    echo "FAIL  $label (expected " . var_export($expected, true) . ', got ' . var_export($actual, true) . ")\n";
}

function check_true($label, $condition)
{
    check($label, (bool) $condition, true);
}

function check_error($label, $result, $expected_code)
{
    check_true($label . ' returns WP_Error', is_wp_error($result));
    check($label . ' error code', is_wp_error($result) ? $result->get_error_code() : null, $expected_code);
}

require_once dirname(__DIR__) . '/includes/class-pge-salla-customer-groups-service.php';

$service = new PGE_Salla_Customer_Groups_Service();

reset_salla_test_state();
$result = $service->add_customer_to_group('invalid', 456, 789);
check_error('invalid merchant_id', $result, 'invalid_salla_merchant_id');
check('invalid merchant_id makes no HTTP request', count($GLOBALS['salla_test_http_calls']), 0);

reset_salla_test_state();
$result = $service->add_customer_to_group(123, 0, 789);
check_error('invalid customer_id', $result, 'invalid_salla_customer_id');
check('invalid customer_id makes no HTTP request', count($GLOBALS['salla_test_http_calls']), 0);

reset_salla_test_state();
$result = $service->add_customer_to_group(123, 456, -1);
check_error('invalid group_id', $result, 'invalid_salla_group_id');
check('invalid group_id makes no HTTP request', count($GLOBALS['salla_test_http_calls']), 0);

reset_salla_test_state();
$GLOBALS['salla_test_options'] = [];
$result = $service->add_customer_to_group(123, 456, 789);
check_error('missing token option', $result, 'salla_tokens_missing');
check('missing token makes no HTTP request', count($GLOBALS['salla_test_http_calls']), 0);

reset_salla_test_state();
$GLOBALS['salla_test_options']['pge_salla_tokens_123'] = 'invalid';
$result = $service->add_customer_to_group(123, 456, 789);
check_error('invalid token data', $result, 'salla_token_data_invalid');
check('invalid token data makes no HTTP request', count($GLOBALS['salla_test_http_calls']), 0);

reset_salla_test_state();
$GLOBALS['salla_test_options']['pge_salla_tokens_123']['access_token'] = '';
$result = $service->add_customer_to_group(123, 456, 789);
check_error('missing access token', $result, 'salla_access_token_missing');
check('missing access token makes no HTTP request', count($GLOBALS['salla_test_http_calls']), 0);

reset_salla_test_state();
$GLOBALS['salla_test_http_response'] = new WP_Error('http_request_failed', 'Simulated transport failure.');
$result = $service->add_customer_to_group(123, 456, 789);
check_error('WordPress HTTP failure', $result, 'salla_customer_group_transport_error');
check('WordPress HTTP failure uses one stub request', count($GLOBALS['salla_test_http_calls']), 1);

reset_salla_test_state();
$GLOBALS['salla_test_http_response'] = [
    'response' => ['code' => 422],
    'body'     => json_encode(['status' => 422, 'success' => false]),
];
$result = $service->add_customer_to_group(123, 456, 789);
check_error('non-2xx response', $result, 'salla_customer_group_http_error');

reset_salla_test_state();
$GLOBALS['salla_test_http_response']['body'] = '';
$result = $service->add_customer_to_group(123, 456, 789);
check_error('empty 2xx response', $result, 'salla_customer_group_empty_response');

reset_salla_test_state();
$GLOBALS['salla_test_http_response']['body'] = '{invalid json';
$result = $service->add_customer_to_group(123, 456, 789);
check_error('invalid JSON response', $result, 'salla_customer_group_invalid_json');

reset_salla_test_state();
$GLOBALS['salla_test_http_response']['body'] = json_encode([
    'status'  => 200,
    'success' => false,
    'data'    => ['message' => 'Rejected by API'],
]);
$result = $service->add_customer_to_group(123, 456, 789);
check_error('2xx API rejection', $result, 'salla_customer_group_api_error');

reset_salla_test_state();
$result = $service->add_customer_to_group(123, 456, 789);
check_true('valid 2xx JSON response succeeds', is_array($result) && ($result['success'] ?? false) === true);
check('success HTTP status', $result['http_status'] ?? null, 200);
check('success API status', $result['api_status'] ?? null, 200);
check('success makes one stub request', count($GLOBALS['salla_test_http_calls']), 1);

$call = $GLOBALS['salla_test_http_calls'][0] ?? [];
check('request endpoint', $call['url'] ?? null, 'https://api.salla.dev/admin/v2/customers/groups/add_customers');
check('Authorization header', $call['args']['headers']['Authorization'] ?? null, 'Bearer test-access-token');
check('Content-Type header', $call['args']['headers']['Content-Type'] ?? null, 'application/json');
check('Accept header', $call['args']['headers']['Accept'] ?? null, 'application/json');
check('request body', json_decode($call['args']['body'] ?? '', true), [
    'group_id'  => 789,
    'customers' => [456],
]);

$service_source = file_get_contents(dirname(__DIR__) . '/includes/class-pge-salla-customer-groups-service.php');
$plugin_source = file_get_contents(dirname(__DIR__) . '/pgevents-core.php');
check_true('group ID is not hardcoded in service', strpos($service_source, '225189340') === false);
check_true('generic service contains no Plus plan logic', strpos($service_source, 'halwa_plus') === false);
check_true(
    'plugin bootstrap loads the service',
    strpos($plugin_source, "require_once PGE_PATH . 'includes/class-pge-salla-customer-groups-service.php';") !== false
);

if ($failures > 0) {
    echo "\n$failures test(s) failed.\n";
    exit(1);
}

echo "\nAll Salla Customer Groups service tests passed. No real HTTP request was possible.\n";
exit(0);

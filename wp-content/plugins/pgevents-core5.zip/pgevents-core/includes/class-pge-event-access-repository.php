<?php
if (!defined('ABSPATH')) exit;

/**
 * Read and transactional group-write access to the five event-access tables.
 *
 * The repository is deliberately static: it owns no request or user state,
 * performs no authorization, and executes SQL only after the schema-readiness
 * and event-scope guards pass. Group mutations and their audit records share
 * one transaction. Membership lifecycle and group-access mutations use the
 * same transaction boundary without owning authorization or request state.
 */
class PGE_Event_Access_Repository
{
    const DEFAULT_PER_PAGE = 20;
    const MAX_PER_PAGE = 100;
    const MAX_PHONE_BATCH = 200;
    const MAX_GROUP_BATCH = 200;

    const GROUP_STATUSES = ['active', 'archived'];
    const MEMBERSHIP_STATUSES = ['active', 'revoked'];
    const MEMBERSHIP_ROLES = ['manager', 'viewer'];
    const AUDIT_ENTITY_TYPES = ['group', 'membership', 'group_access', 'guest_assignment', 'event'];
    const AUDIT_ACTIONS = [
        'group_created',
        'group_renamed',
        'group_archived',
        'default_group_changed',
        'membership_created',
        'membership_reactivated',
        'membership_role_changed',
        'membership_revoked',
        'membership_quota_changed',
        'group_access_granted',
        'group_access_revoked',
        'guest_group_assigned',
        'guest_group_moved',
        'guest_group_unassigned',
    ];

    const GROUP_WRITE_AUDIT_ACTIONS = [
        'group_created',
        'group_renamed',
        'default_group_changed',
        'group_archived',
    ];

    public static function create_group($event_id, $name, $actor_user_id, $make_default = false)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($actor_user_id) || !is_bool($make_default)) return self::invalid_input();
        $name = self::normalize_group_name_input($name);
        if ($name instanceof WP_Error) return $name;

        return self::with_group_transaction($event_id, function (array $groups) use ($event_id, $name, $actor_user_id, $make_default) {
            $duplicate = self::find_locked_group_by_key($groups, $name['name_key']);
            if ($duplicate !== null) return self::duplicate_group();

            $previous_default = self::locked_default_group($groups);
            if ($previous_default instanceof WP_Error) return $previous_default;
            $now = current_time('mysql', true);

            if ($make_default && $previous_default !== null) {
                $cleared = self::update_group_default_slot($event_id, $previous_default['id'], null, $now);
                if ($cleared instanceof WP_Error) return $cleared;
            }

            $table = self::table('groups');
            if ($table instanceof WP_Error) return $table;
            $slot_sql = $make_default ? '%d' : 'NULL';
            $args = [$event_id, $name['name'], $name['name_key'], 'active'];
            if ($make_default) $args[] = 1;
            $args = array_merge($args, [$actor_user_id, $now, $now]);
            global $wpdb;
            $wpdb->insert_id = 0;
            $inserted = self::mutation_query(
                "INSERT INTO $table (event_id, name, name_key, status, default_slot, created_by_user_id, created_at, updated_at, archived_at) VALUES (%d, %s, %s, %s, $slot_sql, %d, %s, %s, NULL)",
                $args
            );
            if ($inserted instanceof WP_Error) {
                return self::translate_duplicate_after_failure($event_id, $name['name_key'], null, $inserted);
            }
            if ($inserted !== 1) return self::database_error();

            $group_id = $wpdb->insert_id ?? null;
            if (!is_int($group_id) || $group_id <= 0) return self::database_error();

            $audit = self::insert_group_audit($event_id, $actor_user_id, 'group_created', $group_id, null, $now);
            if ($audit instanceof WP_Error) return $audit;
            if ($make_default) {
                $metadata = ['previous_group_id' => $previous_default === null ? null : $previous_default['id']];
                $audit = self::insert_group_audit($event_id, $actor_user_id, 'default_group_changed', $group_id, $metadata, $now);
                if ($audit instanceof WP_Error) return $audit;
            }

            $group = self::read_group_inside_transaction($event_id, $group_id);
            if ($group instanceof WP_Error) return $group;
            if ($group['name'] !== $name['name']
                || $group['name_key'] !== $name['name_key']
                || $group['status'] !== 'active'
                || $group['is_default'] !== $make_default
                || $group['created_by_user_id'] !== $actor_user_id
                || $group['created_at'] !== $now
                || $group['updated_at'] !== $now
                || $group['archived_at'] !== null) {
                return self::database_error();
            }
            return ['changed' => true, 'group' => $group];
        });
    }

    public static function rename_group($event_id, $group_id, $expected_name, $new_name, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($group_id) || !self::valid_id($actor_user_id)) return self::invalid_input();
        $expected = self::normalize_group_name_input($expected_name);
        if ($expected instanceof WP_Error) return $expected;
        $new = self::normalize_group_name_input($new_name);
        if ($new instanceof WP_Error) return $new;

        return self::with_group_transaction($event_id, function (array $groups) use ($event_id, $group_id, $expected, $new, $actor_user_id) {
            $group = self::find_locked_group_by_id($groups, $group_id);
            if ($group === null) return self::not_found();
            if ($group['status'] !== 'active') return self::invalid_state();
            if ($group['name'] !== $expected['name']) return self::concurrent_update();
            if ($group['name'] === $new['name'] && $group['name_key'] === $new['name_key']) {
                return ['changed' => false, 'group' => $group];
            }
            $duplicate = self::find_locked_group_by_key($groups, $new['name_key'], $group_id);
            if ($duplicate !== null) return self::duplicate_group();

            $now = current_time('mysql', true);
            $table = self::table('groups');
            if ($table instanceof WP_Error) return $table;
            $updated = self::mutation_query(
                "UPDATE $table SET name = %s, name_key = %s, updated_at = %s WHERE event_id = %d AND id = %d AND status = %s",
                [$new['name'], $new['name_key'], $now, $event_id, $group_id, 'active']
            );
            if ($updated instanceof WP_Error) {
                return self::translate_duplicate_after_failure($event_id, $new['name_key'], $group_id, $updated);
            }
            if ($updated !== 1) return $updated === 0 ? self::concurrent_update() : self::database_error();
            $audit = self::insert_group_audit($event_id, $actor_user_id, 'group_renamed', $group_id, null, $now);
            if ($audit instanceof WP_Error) return $audit;
            $group = self::read_group_inside_transaction($event_id, $group_id);
            if ($group instanceof WP_Error) return $group;
            return ['changed' => true, 'group' => $group];
        });
    }

    public static function set_default_group($event_id, $group_id, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($group_id) || !self::valid_id($actor_user_id)) return self::invalid_input();

        return self::with_group_transaction($event_id, function (array $groups) use ($event_id, $group_id, $actor_user_id) {
            $target = self::find_locked_group_by_id($groups, $group_id);
            if ($target === null) return self::not_found();
            if ($target['status'] !== 'active') return self::invalid_state();
            $previous = self::locked_default_group($groups);
            if ($previous instanceof WP_Error) return $previous;
            if ($previous !== null && $previous['id'] === $group_id) {
                return ['changed' => false, 'group' => $target];
            }

            $now = current_time('mysql', true);
            if ($previous !== null) {
                $cleared = self::update_group_default_slot($event_id, $previous['id'], null, $now);
                if ($cleared instanceof WP_Error) return $cleared;
            }
            $set = self::update_group_default_slot($event_id, $group_id, 1, $now);
            if ($set instanceof WP_Error) return $set;
            $metadata = ['previous_group_id' => $previous === null ? null : $previous['id']];
            $audit = self::insert_group_audit($event_id, $actor_user_id, 'default_group_changed', $group_id, $metadata, $now);
            if ($audit instanceof WP_Error) return $audit;
            $group = self::read_group_inside_transaction($event_id, $group_id);
            if ($group instanceof WP_Error) return $group;
            return ['changed' => true, 'group' => $group];
        });
    }

    public static function archive_group($event_id, $group_id, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($group_id) || !self::valid_id($actor_user_id)) return self::invalid_input();

        return self::with_group_transaction($event_id, function (array $groups) use ($event_id, $group_id, $actor_user_id) {
            $target = self::find_locked_group_by_id($groups, $group_id);
            if ($target === null) return self::not_found();
            if ($target['status'] === 'archived') return ['changed' => false, 'group' => $target];

            $was_default = $target['is_default'];
            $now = current_time('mysql', true);
            $table = self::table('groups');
            if ($table instanceof WP_Error) return $table;
            $updated = self::mutation_query(
                "UPDATE $table SET status = %s, name_key = NULL, default_slot = NULL, archived_at = %s, updated_at = %s WHERE event_id = %d AND id = %d AND status = %s",
                ['archived', $now, $now, $event_id, $group_id, 'active']
            );
            if ($updated instanceof WP_Error) return $updated;
            if ($updated !== 1) return $updated === 0 ? self::concurrent_update() : self::database_error();
            $audit = self::insert_group_audit($event_id, $actor_user_id, 'group_archived', $group_id, ['was_default' => $was_default], $now);
            if ($audit instanceof WP_Error) return $audit;
            $group = self::read_group_inside_transaction($event_id, $group_id);
            if ($group instanceof WP_Error) return $group;
            return ['changed' => true, 'group' => $group];
        });
    }

    public static function create_membership($event_id, $user_id, $role, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($user_id) || !self::valid_role($role) || !self::valid_id($actor_user_id)) return self::invalid_input();
        $user = self::require_user($user_id);
        if ($user instanceof WP_Error) return $user;

        return self::with_event_transaction(function () use ($event_id, $user_id, $role, $actor_user_id) {
            $memberships = self::lock_memberships($event_id);
            if ($memberships instanceof WP_Error) return $memberships;
            if (self::find_locked_membership_by_user($memberships, $user_id) !== null) return self::duplicate_membership();
            $now = current_time('mysql', true);
            $table = self::table('memberships');
            if ($table instanceof WP_Error) return $table;
            global $wpdb;
            $wpdb->insert_id = 0;
            $inserted = self::mutation_query(
                "INSERT INTO $table (event_id, user_id, role, status, created_by_user_id, activated_at, revoked_at, created_at, updated_at) VALUES (%d, %d, %s, %s, %d, %s, NULL, %s, %s)",
                [$event_id, $user_id, $role, 'active', $actor_user_id, $now, $now, $now]
            );
            if ($inserted instanceof WP_Error) {
                $existing = self::read_membership_for_user_inside_transaction($event_id, $user_id);
                return is_array($existing) ? self::duplicate_membership() : $inserted;
            }
            if ($inserted !== 1) return self::database_error();
            $membership_id = $wpdb->insert_id ?? null;
            if (!is_int($membership_id) || $membership_id <= 0) return self::database_error();
            $membership = self::read_membership_inside_transaction($event_id, $membership_id);
            if ($membership instanceof WP_Error) return $membership;
            if (!self::membership_matches_create($membership, $user_id, $role, $actor_user_id, $now)) return self::database_error();
            $audit = self::insert_audit($event_id, $actor_user_id, 'membership_created', 'membership', $membership_id, ['role' => $role], $now);
            if ($audit instanceof WP_Error) return $audit;
            return ['changed' => true, 'membership' => $membership];
        });
    }

    public static function change_membership_role($event_id, $membership_id, $expected_role, $new_role, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($membership_id) || !self::valid_role($expected_role) || !self::valid_role($new_role) || !self::valid_id($actor_user_id)) return self::invalid_input();
        return self::with_event_transaction(function () use ($event_id, $membership_id, $expected_role, $new_role, $actor_user_id) {
            $memberships = self::lock_memberships($event_id);
            if ($memberships instanceof WP_Error) return $memberships;
            $membership = self::find_locked_membership_by_id($memberships, $membership_id);
            if ($membership === null) return self::not_found();
            $user = self::require_user($membership['user_id']);
            if ($user instanceof WP_Error) return $user;
            if ($membership['status'] !== 'active') return self::invalid_state();
            if ($membership['role'] !== $expected_role) return self::concurrent_update();
            if ($expected_role === $new_role) return ['changed' => false, 'membership' => $membership];

            // H1C-W8 Fix Pass 2 — if this transition would leave the
            // membership satisfying the Additional-Inviter predicate
            // (active + manager + allocated_quota IS NOT NULL — e.g. a
            // Viewer with a quota already set on it transitioning to
            // Manager), it must pass the same one-group + exclusivity
            // guard as every other path that can construct that
            // predicate. Evaluated against the membership's state AFTER
            // the role change, not before. A transition OUT of manager,
            // or on a membership with allocated_quota = NULL, is never a
            // candidate and is entirely unaffected — no role is ever
            // auto-changed, no quota is ever auto-cleared, no access is
            // ever auto-touched by this guard; it only ever fails closed.
            $candidate_after = $membership; $candidate_after['role'] = $new_role;
            $conflict = self::guard_quota_inviter_shape($event_id, $memberships, $candidate_after);
            if ($conflict instanceof WP_Error) return $conflict;

            $now = current_time('mysql', true);
            $table = self::table('memberships');
            if ($table instanceof WP_Error) return $table;
            $updated = self::mutation_query("UPDATE $table SET role = %s, updated_at = %s WHERE event_id = %d AND id = %d AND status = %s AND role = %s", [$new_role, $now, $event_id, $membership_id, 'active', $expected_role]);
            if ($updated instanceof WP_Error) return $updated;
            if ($updated !== 1) return $updated === 0 ? self::concurrent_update() : self::database_error();
            $after = self::read_membership_inside_transaction($event_id, $membership_id);
            if ($after instanceof WP_Error) return $after;
            if ($after['role'] !== $new_role || $after['status'] !== 'active' || $after['updated_at'] !== $now) return self::database_error();
            $audit = self::insert_audit($event_id, $actor_user_id, 'membership_role_changed', 'membership', $membership_id, ['previous_role' => $expected_role, 'new_role' => $new_role], $now);
            if ($audit instanceof WP_Error) return $audit;
            return ['changed' => true, 'membership' => $after];
        });
    }

    public static function revoke_membership($event_id, $membership_id, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($membership_id) || !self::valid_id($actor_user_id)) return self::invalid_input();
        return self::with_event_transaction(function () use ($event_id, $membership_id, $actor_user_id) {
            $memberships = self::lock_memberships($event_id);
            if ($memberships instanceof WP_Error) return $memberships;
            $membership = self::find_locked_membership_by_id($memberships, $membership_id);
            if ($membership === null) return self::not_found();
            $access_rows = self::lock_membership_access($event_id, $membership_id);
            if ($access_rows instanceof WP_Error) return $access_rows;
            $count = count($access_rows);
            if ($membership['status'] === 'revoked' && $count === 0) return ['changed' => false, 'membership' => $membership];
            $now = current_time('mysql', true);
            $status_changed = $membership['status'] === 'active';
            if ($status_changed) {
                $table = self::table('memberships');
                if ($table instanceof WP_Error) return $table;
                $updated = self::mutation_query("UPDATE $table SET status = %s, revoked_at = %s, updated_at = %s WHERE event_id = %d AND id = %d AND status = %s", ['revoked', $now, $now, $event_id, $membership_id, 'active']);
                if ($updated instanceof WP_Error) return $updated;
                if ($updated !== 1) return $updated === 0 ? self::concurrent_update() : self::database_error();
            }
            if ($count > 0) {
                $access = self::table('access');
                if ($access instanceof WP_Error) return $access;
                $deleted = self::delete_rows($access, ['event_id' => $event_id, 'membership_id' => $membership_id], ['%d', '%d']);
                if ($deleted instanceof WP_Error) return $deleted;
                if ($deleted !== $count) return is_int($deleted) && $deleted >= 0 ? self::concurrent_update() : self::database_error();
            }
            $remaining = self::lock_membership_access($event_id, $membership_id);
            if ($remaining instanceof WP_Error || $remaining !== []) return self::database_error();
            $after = self::read_membership_inside_transaction($event_id, $membership_id);
            if ($after instanceof WP_Error) return $after;
            if ($after['status'] !== 'revoked' || $after['revoked_at'] === null || ($status_changed && $after['updated_at'] !== $now)) return self::database_error();
            $audit = self::insert_audit($event_id, $actor_user_id, 'membership_revoked', 'membership', $membership_id, ['status_changed' => $status_changed, 'revoked_group_access_count' => $count], $now);
            if ($audit instanceof WP_Error) return $audit;
            return ['changed' => true, 'membership' => $after];
        });
    }

    public static function reactivate_membership($event_id, $membership_id, $role, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($membership_id) || !self::valid_role($role) || !self::valid_id($actor_user_id)) return self::invalid_input();
        return self::with_event_transaction(function () use ($event_id, $membership_id, $role, $actor_user_id) {
            $memberships = self::lock_memberships($event_id);
            if ($memberships instanceof WP_Error) return $memberships;
            $membership = self::find_locked_membership_by_id($memberships, $membership_id);
            if ($membership === null) return self::not_found();
            $user = self::require_user($membership['user_id']);
            if ($user instanceof WP_Error) return $user;
            $access_rows = self::lock_membership_access($event_id, $membership_id);
            if ($access_rows instanceof WP_Error) return $access_rows;
            if ($membership['status'] === 'active') return $membership['role'] === $role ? ['changed' => false, 'membership' => $membership] : self::invalid_state();
            if ($access_rows !== []) return self::database_error();

            // H1C-W8 Fix Pass — group exclusivity guard, scoped to
            // quota-enabled memberships only (allocated_quota !== null),
            // exactly as Section 6 requires. Honest note on reachability:
            // under the CURRENT architecture this specific check can never
            // actually fire, because revoke_membership() unconditionally
            // deletes every access row for the membership it revokes, and
            // the "$access_rows !== []" integrity check directly above
            // already guarantees $access_rows is empty by the time
            // execution reaches here — so there is no group left to check
            // a conflict against. It is kept as real, correct defense-in-
            // depth against any future change that loosens that
            // guarantee (e.g. a revoke variant that preserves access), not
            // as a currently-reachable code path. It does NOT close the
            // related two-step gap (reactivate with zero groups, then a
            // separate grant_group_access() call) — see the Final Report.
            if ($membership['allocated_quota'] !== null) {
                foreach ($access_rows as $access) {
                    $conflict = self::ensure_no_active_quota_inviter_for_group(
                        $event_id, $memberships, $access['group_id'], $membership_id
                    );
                    if ($conflict instanceof WP_Error) return $conflict;
                }
            }

            $now = current_time('mysql', true);
            $table = self::table('memberships');
            if ($table instanceof WP_Error) return $table;
            $updated = self::mutation_query("UPDATE $table SET status = %s, role = %s, activated_at = %s, revoked_at = NULL, updated_at = %s WHERE event_id = %d AND id = %d AND status = %s", ['active', $role, $now, $now, $event_id, $membership_id, 'revoked']);
            if ($updated instanceof WP_Error) return $updated;
            if ($updated !== 1) return $updated === 0 ? self::concurrent_update() : self::database_error();
            $after = self::read_membership_inside_transaction($event_id, $membership_id);
            if ($after instanceof WP_Error) return $after;
            if ($after['status'] !== 'active' || $after['role'] !== $role || $after['activated_at'] !== $now || $after['revoked_at'] !== null || $after['updated_at'] !== $now) return self::database_error();
            $audit = self::insert_audit($event_id, $actor_user_id, 'membership_reactivated', 'membership', $membership_id, ['previous_role' => $membership['role'], 'new_role' => $role], $now);
            if ($audit instanceof WP_Error) return $audit;
            return ['changed' => true, 'membership' => $after];
        });
    }

    /**
     * H1C-W8 — Additional Inviter Quota. Owner/Admin-only CAS mutation of a
     * single membership's allocated_quota, following the identical
     * expected/new compare-and-swap shape change_membership_role() already
     * uses. $expected_quota/$new_quota are each either null (no quota
     * configured) or a strict positive int — 0 is never accepted (see
     * valid_id()). Setting $new_quota to null reverts the membership to an
     * ordinary (non-Additional-Inviter) H1C membership; it does not revoke
     * the membership or touch group access/guest assignments.
     */
    public static function set_membership_quota($event_id, $membership_id, $expected_quota, $new_quota, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($membership_id) || !self::valid_id($actor_user_id)) return self::invalid_input();
        if ($expected_quota !== null && !self::valid_id($expected_quota)) return self::invalid_input();
        if ($new_quota !== null && !self::valid_id($new_quota)) return self::invalid_input();

        return self::with_event_transaction(function () use ($event_id, $membership_id, $expected_quota, $new_quota, $actor_user_id) {
            $memberships = self::lock_memberships($event_id);
            if ($memberships instanceof WP_Error) return $memberships;
            $membership = self::find_locked_membership_by_id($memberships, $membership_id);
            if ($membership === null) return self::not_found();
            if ($membership['status'] !== 'active') return self::invalid_state();
            if ($membership['allocated_quota'] !== $expected_quota) return self::concurrent_update();
            if ($expected_quota === $new_quota) return ['changed' => false, 'membership' => $membership];

            // H1C-W8 Fix Pass — raising a membership to quota-enabled (or
            // changing an already quota-enabled membership's quota value)
            // must never leave a half-configured or group-conflicting
            // Additional Inviter. This block runs ONLY when $new_quota is
            // non-null: setting quota back to NULL (removing Additional-
            // Inviter semantics) never needs these checks, never touches
            // role/group access, and never "fixes" configuration silently.
            if ($new_quota !== null) {
                if ($membership['role'] !== 'manager') return self::invalid_state();
                $access_rows = self::lock_membership_access($event_id, $membership_id);
                if ($access_rows instanceof WP_Error) return $access_rows;
                if (count($access_rows) !== 1) return self::invalid_state();
                $conflict = self::ensure_no_active_quota_inviter_for_group(
                    $event_id, $memberships, $access_rows[0]['group_id'], $membership_id
                );
                if ($conflict instanceof WP_Error) return $conflict;
            }

            $now = current_time('mysql', true);
            $table = self::table('memberships');
            if ($table instanceof WP_Error) return $table;

            if ($expected_quota === null) {
                $where_sql = 'allocated_quota IS NULL';
                $where_args = [];
            } else {
                $where_sql = 'allocated_quota = %d';
                $where_args = [$expected_quota];
            }
            if ($new_quota === null) {
                $set_sql = 'allocated_quota = NULL';
                $set_args = [];
            } else {
                $set_sql = 'allocated_quota = %d';
                $set_args = [$new_quota];
            }

            $updated = self::mutation_query(
                "UPDATE $table SET $set_sql, updated_at = %s WHERE event_id = %d AND id = %d AND status = %s AND $where_sql",
                array_merge($set_args, [$now, $event_id, $membership_id, 'active'], $where_args)
            );
            if ($updated instanceof WP_Error) return $updated;
            if ($updated !== 1) return $updated === 0 ? self::concurrent_update() : self::database_error();

            $after = self::read_membership_inside_transaction($event_id, $membership_id);
            if ($after instanceof WP_Error) return $after;
            if ($after['allocated_quota'] !== $new_quota || $after['status'] !== 'active' || $after['updated_at'] !== $now) {
                return self::database_error();
            }
            $audit = self::insert_audit($event_id, $actor_user_id, 'membership_quota_changed', 'membership', $membership_id, ['previous_quota' => $expected_quota, 'new_quota' => $new_quota], $now);
            if ($audit instanceof WP_Error) return $audit;
            return ['changed' => true, 'membership' => $after];
        });
    }

    /**
     * H1C-W8 — Additional Inviter Quota. Owner/Admin-only, all-or-nothing
     * creation of a Manager membership PLUS exactly one group grant PLUS its
     * quota, in a single with_event_transaction() (same transaction
     * primitive create_group()/grant_group_access() already use) — no
     * partially-configured Additional Inviter can ever be observed by any
     * other request: either the membership row, the access row, and both
     * audit rows all commit together, or none of them do (the transaction
     * rolls back on any WP_Error returned from inside the callback, exactly
     * like every other with_event_transaction() caller in this file).
     *
     * Deliberately composed from the exact same locking/insert/audit
     * primitives create_membership() and grant_group_access() already use
     * (lock_groups, lock_memberships, the find_locked_ helpers,
     * mutation_query, insert_audit, the read_..._inside_transaction
     * helpers) rather than calling those two methods as separate
     * transactions — this is what makes the whole operation genuinely
     * atomic instead of "two atomic steps that could still be observed
     * half-done between them."
     */
    public static function create_additional_inviter_membership($event_id, $user_id, $group_id, $allocated_quota, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($user_id) || !self::valid_id($group_id) || !self::valid_id($actor_user_id) || !self::valid_id($allocated_quota)) {
            return self::invalid_input();
        }
        $user = self::require_user($user_id);
        if ($user instanceof WP_Error) return $user;

        return self::with_event_transaction(function () use ($event_id, $user_id, $group_id, $allocated_quota, $actor_user_id) {
            $groups = self::lock_groups($event_id);
            if ($groups instanceof WP_Error) return self::write_storage_error($groups);
            $memberships = self::lock_memberships($event_id);
            if ($memberships instanceof WP_Error) return $memberships;

            $group = self::find_locked_group_by_id($groups, $group_id);
            if ($group === null) return self::not_found();
            if ($group['status'] !== 'active') return self::invalid_state();
            if (self::find_locked_membership_by_user($memberships, $user_id) !== null) return self::duplicate_membership();

            // H1C-W8 Fix Pass — group exclusivity: this is a brand-new
            // membership, so there is no membership_id to except yet.
            $conflict = self::ensure_no_active_quota_inviter_for_group($event_id, $memberships, $group_id, null);
            if ($conflict instanceof WP_Error) return $conflict;

            $now = current_time('mysql', true);
            $table = self::table('memberships');
            if ($table instanceof WP_Error) return $table;
            global $wpdb;
            $wpdb->insert_id = 0;
            $inserted = self::mutation_query(
                "INSERT INTO $table (event_id, user_id, role, status, allocated_quota, created_by_user_id, activated_at, revoked_at, created_at, updated_at) VALUES (%d, %d, %s, %s, %d, %d, %s, NULL, %s, %s)",
                [$event_id, $user_id, 'manager', 'active', $allocated_quota, $actor_user_id, $now, $now, $now]
            );
            if ($inserted instanceof WP_Error) {
                $existing = self::read_membership_for_user_inside_transaction($event_id, $user_id);
                return is_array($existing) ? self::duplicate_membership() : $inserted;
            }
            if ($inserted !== 1) return self::database_error();
            $membership_id = $wpdb->insert_id ?? null;
            if (!is_int($membership_id) || $membership_id <= 0) return self::database_error();

            $membership = self::read_membership_inside_transaction($event_id, $membership_id);
            if ($membership instanceof WP_Error) return $membership;
            if ($membership['role'] !== 'manager' || $membership['status'] !== 'active' || $membership['allocated_quota'] !== $allocated_quota) {
                return self::database_error();
            }
            $audit = self::insert_audit($event_id, $actor_user_id, 'membership_created', 'membership', $membership_id, ['role' => 'manager', 'allocated_quota' => $allocated_quota], $now);
            if ($audit instanceof WP_Error) return $audit;

            $access_table = self::table('access');
            if ($access_table instanceof WP_Error) return $access_table;
            $wpdb->insert_id = 0;
            $access_inserted = self::mutation_query(
                "INSERT INTO $access_table (event_id, membership_id, group_id, granted_by_user_id, created_at) VALUES (%d, %d, %d, %d, %s)",
                [$event_id, $membership_id, $group_id, $actor_user_id, $now]
            );
            if ($access_inserted instanceof WP_Error) return $access_inserted;
            if ($access_inserted !== 1) return self::database_error();
            $access_id = $wpdb->insert_id ?? null;
            if (!is_int($access_id) || $access_id <= 0) return self::database_error();

            $access_after = self::read_access_relation_inside_transaction($event_id, $membership_id, $group_id);
            if ($access_after instanceof WP_Error) return $access_after;
            if ($access_after === null || $access_after['id'] !== $access_id) return self::database_error();

            $access_audit = self::insert_audit($event_id, $actor_user_id, 'group_access_granted', 'group_access', $access_id, ['membership_id' => $membership_id, 'group_id' => $group_id], $now);
            if ($access_audit instanceof WP_Error) return $access_audit;

            return ['changed' => true, 'membership' => $membership, 'group_id' => $group_id];
        });
    }

    public static function grant_group_access($event_id, $membership_id, $group_id, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($membership_id) || !self::valid_id($group_id) || !self::valid_id($actor_user_id)) return self::invalid_input();
        return self::with_event_transaction(function () use ($event_id, $membership_id, $group_id, $actor_user_id) {
            $groups = self::lock_groups($event_id);
            if ($groups instanceof WP_Error) return self::write_storage_error($groups);
            $memberships = self::lock_memberships($event_id);
            if ($memberships instanceof WP_Error) return $memberships;
            $group = self::find_locked_group_by_id($groups, $group_id);
            $membership = self::find_locked_membership_by_id($memberships, $membership_id);
            if ($group === null || $membership === null) return self::not_found();
            $user = self::require_user($membership['user_id']);
            if ($user instanceof WP_Error) return $user;
            if ($group['status'] !== 'active' || $membership['status'] !== 'active') return self::invalid_state();
            $relation = self::lock_access_relation($event_id, $membership_id, $group_id);
            if ($relation instanceof WP_Error) return $relation;
            if ($relation !== null) return ['changed' => false, 'membership_id' => $membership_id, 'group_id' => $group_id, 'has_access' => true];

            // H1C-W8 Fix Pass 2 — this grant would put a NEW group onto
            // $membership; if that membership is (or would remain) a
            // quota-enabled Additional-Inviter candidate, it must still
            // satisfy the one-group + exclusivity invariant afterwards.
            // Generic (allocated_quota = NULL) memberships are unaffected.
            $conflict = self::guard_quota_inviter_shape($event_id, $memberships, $membership, $group_id);
            if ($conflict instanceof WP_Error) return $conflict;

            $now = current_time('mysql', true);
            $table = self::table('access');
            if ($table instanceof WP_Error) return $table;
            global $wpdb;
            $wpdb->insert_id = 0;
            $inserted = self::mutation_query("INSERT INTO $table (event_id, membership_id, group_id, granted_by_user_id, created_at) VALUES (%d, %d, %d, %d, %s)", [$event_id, $membership_id, $group_id, $actor_user_id, $now]);
            if ($inserted instanceof WP_Error) return $inserted;
            if ($inserted !== 1) return self::database_error();
            $access_id = $wpdb->insert_id ?? null;
            if (!is_int($access_id) || $access_id <= 0) return self::database_error();
            $after = self::read_access_relation_inside_transaction($event_id, $membership_id, $group_id);
            if ($after instanceof WP_Error) return $after;
            if ($after === null || $after['id'] !== $access_id || $after['granted_by_user_id'] !== $actor_user_id || $after['created_at'] !== $now) return self::database_error();
            $audit = self::insert_audit($event_id, $actor_user_id, 'group_access_granted', 'group_access', $access_id, ['membership_id' => $membership_id, 'group_id' => $group_id], $now);
            if ($audit instanceof WP_Error) return $audit;
            return ['changed' => true, 'membership_id' => $membership_id, 'group_id' => $group_id, 'has_access' => true];
        });
    }

    public static function revoke_group_access($event_id, $membership_id, $group_id, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($membership_id) || !self::valid_id($group_id) || !self::valid_id($actor_user_id)) return self::invalid_input();
        return self::with_event_transaction(function () use ($event_id, $membership_id, $group_id, $actor_user_id) {
            $groups = self::lock_groups($event_id);
            if ($groups instanceof WP_Error) return self::write_storage_error($groups);
            $memberships = self::lock_memberships($event_id);
            if ($memberships instanceof WP_Error) return $memberships;
            if (self::find_locked_group_by_id($groups, $group_id) === null || self::find_locked_membership_by_id($memberships, $membership_id) === null) return self::not_found();
            $relation = self::lock_access_relation($event_id, $membership_id, $group_id);
            if ($relation instanceof WP_Error) return $relation;
            if ($relation === null) return ['changed' => false, 'membership_id' => $membership_id, 'group_id' => $group_id, 'has_access' => false];
            $table = self::table('access');
            if ($table instanceof WP_Error) return $table;
            $deleted = self::delete_rows($table, ['event_id' => $event_id, 'membership_id' => $membership_id, 'group_id' => $group_id], ['%d', '%d', '%d']);
            if ($deleted instanceof WP_Error) return $deleted;
            if ($deleted !== 1) return $deleted === 0 ? self::concurrent_update() : self::database_error();
            $after = self::read_access_relation_inside_transaction($event_id, $membership_id, $group_id);
            if ($after instanceof WP_Error || $after !== null) return self::database_error();
            $now = current_time('mysql', true);
            $audit = self::insert_audit($event_id, $actor_user_id, 'group_access_revoked', 'group_access', $relation['id'], ['membership_id' => $membership_id, 'group_id' => $group_id], $now);
            if ($audit instanceof WP_Error) return $audit;
            return ['changed' => true, 'membership_id' => $membership_id, 'group_id' => $group_id, 'has_access' => false];
        });
    }

    public static function assign_guest_to_group($event_id, $guest_phone, $group_id, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($group_id) || !self::valid_id($actor_user_id)) return self::invalid_input();
        $phone = self::normalize_phone_input($guest_phone);
        if ($phone instanceof WP_Error) return $phone;
        $guest = self::require_current_guest($event_id, $phone);
        if ($guest instanceof WP_Error) return $guest;

        return self::with_event_transaction(function () use ($event_id, $phone, $group_id, $actor_user_id) {
            $groups = self::lock_groups($event_id);
            if ($groups instanceof WP_Error) return self::write_storage_error($groups);
            $assignment = self::lock_guest_assignment($event_id, $phone);
            if ($assignment instanceof WP_Error) return $assignment;
            if ($assignment !== null) {
                $current_group = self::validate_assignment_group_reference($assignment, $groups, $event_id);
                if ($current_group instanceof WP_Error) return $current_group;
            }
            $target = self::find_locked_group_by_id($groups, $group_id);
            if ($target === null) return self::not_found();
            if ($target['status'] !== 'active') return self::invalid_state();

            if ($assignment !== null) {
                if ($assignment['group_id'] !== $group_id) return self::concurrent_update();
                return self::assignment_write_result(false, $assignment['id'], $group_id, true);
            }

            $now = current_time('mysql', true);
            $table = self::table('assignments');
            if ($table instanceof WP_Error) return $table;
            global $wpdb;
            $wpdb->insert_id = 0;
            $inserted = self::mutation_query(
                "INSERT INTO $table (event_id, guest_phone, group_id, assigned_by_user_id, created_at, updated_at) VALUES (%d, %s, %d, %d, %s, %s)",
                [$event_id, $phone, $group_id, $actor_user_id, $now, $now]
            );
            if ($inserted instanceof WP_Error) {
                $raced = self::read_assignment_inside_transaction($event_id, $phone);
                if (is_array($raced)) {
                    $race_group = self::validate_assignment_group_reference($raced, $groups, $event_id);
                    if (!($race_group instanceof WP_Error) && $race_group !== 'missing') return self::concurrent_update();
                }
                return self::database_error();
            }
            if ($inserted !== 1) return self::database_error();
            $assignment_id = $wpdb->insert_id ?? null;
            if (!is_int($assignment_id) || $assignment_id <= 0) return self::database_error();

            $after = self::read_assignment_inside_transaction($event_id, $phone);
            if ($after instanceof WP_Error || $after === null
                || !self::assignment_matches_create($after, $assignment_id, $event_id, $phone, $group_id, $actor_user_id, $now)) {
                return self::database_error();
            }
            $audit = self::insert_audit($event_id, $actor_user_id, 'guest_group_assigned', 'guest_assignment', $assignment_id, ['group_id' => $group_id], $now);
            if ($audit instanceof WP_Error) return $audit;
            return self::assignment_write_result(true, $assignment_id, $group_id, true);
        });
    }

    public static function move_guest_to_group($event_id, $guest_phone, $expected_group_id, $new_group_id, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($expected_group_id) || !self::valid_id($new_group_id) || !self::valid_id($actor_user_id)) return self::invalid_input();
        $phone = self::normalize_phone_input($guest_phone);
        if ($phone instanceof WP_Error) return $phone;
        $guest = self::require_current_guest($event_id, $phone);
        if ($guest instanceof WP_Error) return $guest;

        return self::with_event_transaction(function () use ($event_id, $phone, $expected_group_id, $new_group_id, $actor_user_id) {
            $groups = self::lock_groups($event_id);
            if ($groups instanceof WP_Error) return self::write_storage_error($groups);
            $assignment = self::lock_guest_assignment($event_id, $phone);
            if ($assignment instanceof WP_Error) return $assignment;
            if ($assignment === null) return self::concurrent_update();
            $current_group = self::validate_assignment_group_reference($assignment, $groups, $event_id);
            if ($current_group instanceof WP_Error) return $current_group;
            if ($assignment['group_id'] !== $expected_group_id) return self::concurrent_update();
            $target = self::find_locked_group_by_id($groups, $new_group_id);
            if ($target === null) return self::not_found();
            if ($target['status'] !== 'active') return self::invalid_state();
            if ($expected_group_id === $new_group_id) {
                return self::assignment_write_result(false, $assignment['id'], $assignment['group_id'], true);
            }

            $now = current_time('mysql', true);
            $table = self::table('assignments');
            if ($table instanceof WP_Error) return $table;
            $updated = self::mutation_query(
                "UPDATE $table SET group_id = %d, assigned_by_user_id = %d, updated_at = %s WHERE id = %d AND event_id = %d AND guest_phone = %s AND group_id = %d",
                [$new_group_id, $actor_user_id, $now, $assignment['id'], $event_id, $phone, $expected_group_id]
            );
            if ($updated instanceof WP_Error) return $updated;
            if ($updated !== 1) return $updated === 0 ? self::concurrent_update() : self::database_error();

            $after = self::read_assignment_inside_transaction($event_id, $phone);
            if ($after instanceof WP_Error || $after === null
                || $after['id'] !== $assignment['id'] || $after['event_id'] !== $event_id
                || $after['guest_phone'] !== $phone || $after['group_id'] !== $new_group_id
                || $after['assigned_by_user_id'] !== $actor_user_id
                || $after['created_at'] !== $assignment['created_at'] || $after['updated_at'] !== $now) {
                return self::database_error();
            }
            $audit = self::insert_audit($event_id, $actor_user_id, 'guest_group_moved', 'guest_assignment', $assignment['id'], ['previous_group_id' => $expected_group_id, 'new_group_id' => $new_group_id], $now);
            if ($audit instanceof WP_Error) return $audit;
            return self::assignment_write_result(true, $assignment['id'], $new_group_id, true);
        });
    }

    public static function unassign_guest_from_group($event_id, $guest_phone, $expected_group_id, $actor_user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($expected_group_id) || !self::valid_id($actor_user_id)) return self::invalid_input();
        $phone = self::normalize_phone_input($guest_phone);
        if ($phone instanceof WP_Error) return $phone;

        return self::with_event_transaction(function () use ($event_id, $phone, $expected_group_id, $actor_user_id) {
            $groups = self::lock_groups($event_id);
            if ($groups instanceof WP_Error) return self::write_storage_error($groups);
            $assignment = self::lock_guest_assignment($event_id, $phone);
            if ($assignment instanceof WP_Error) return $assignment;
            if ($assignment === null) return self::assignment_write_result(false, null, null, false);
            $current_group = self::validate_assignment_group_reference($assignment, $groups, $event_id);
            if ($current_group instanceof WP_Error) return $current_group;
            if ($assignment['group_id'] !== $expected_group_id) return self::concurrent_update();

            $table = self::table('assignments');
            if ($table instanceof WP_Error) return $table;
            $deleted = self::delete_rows(
                $table,
                ['id' => $assignment['id'], 'event_id' => $event_id, 'guest_phone' => $phone, 'group_id' => $expected_group_id],
                ['%d', '%d', '%s', '%d']
            );
            if ($deleted instanceof WP_Error) return $deleted;
            if ($deleted !== 1) return $deleted === 0 ? self::concurrent_update() : self::database_error();
            $after = self::read_assignment_inside_transaction($event_id, $phone);
            if ($after instanceof WP_Error || $after !== null) return self::database_error();

            $now = current_time('mysql', true);
            $audit = self::insert_audit($event_id, $actor_user_id, 'guest_group_unassigned', 'guest_assignment', $assignment['id'], ['previous_group_id' => $expected_group_id], $now);
            if ($audit instanceof WP_Error) return $audit;
            return self::assignment_write_result(true, null, null, false);
        });
    }

    public static function get_group($event_id, $group_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($group_id)) return self::invalid_input();

        $table = self::table('groups');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row(
            "SELECT * FROM $table WHERE event_id = %d AND id = %d LIMIT 2",
            [$event_id, $group_id]
        );
        if ($row instanceof WP_Error) return $row;
        if ($row === null) return self::not_found();
        return self::normalize_group($row, $event_id);
    }

    public static function list_groups($event_id, $filters = [], $page = 1, $per_page = self::DEFAULT_PER_PAGE)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        $pagination = self::validate_pagination($page, $per_page);
        if ($pagination instanceof WP_Error) return $pagination;
        if (!is_array($filters) || !self::only_filters($filters, ['status'])) return self::invalid_filter();

        $where = ['event_id = %d'];
        $args = [$event_id];
        if (array_key_exists('status', $filters)) {
            if (!is_string($filters['status']) || !in_array($filters['status'], self::GROUP_STATUSES, true)) {
                return self::invalid_filter();
            }
            $where[] = 'status = %s';
            $args[] = $filters['status'];
        }

        $table = self::table('groups');
        if ($table instanceof WP_Error) return $table;
        return self::paginate(
            $table,
            implode(' AND ', $where),
            $args,
            'ORDER BY id ASC',
            $pagination,
            function ($row) use ($event_id) { return self::normalize_group($row, $event_id); }
        );
    }

    public static function get_default_group($event_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        $table = self::table('groups');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row(
            "SELECT * FROM $table WHERE event_id = %d AND default_slot = %d AND status = %s LIMIT 2",
            [$event_id, 1, 'active']
        );
        return $row instanceof WP_Error || $row === null ? $row : self::normalize_group($row, $event_id);
    }

    public static function find_active_group_by_name_key($event_id, $name_key)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!is_string($name_key)) return self::invalid_input();
        $name_key = trim($name_key);
        if ($name_key === '' || self::string_length($name_key) > 160) return self::invalid_input();

        $table = self::table('groups');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row(
            "SELECT * FROM $table WHERE event_id = %d AND name_key = %s AND status = %s LIMIT 2",
            [$event_id, $name_key, 'active']
        );
        return $row instanceof WP_Error || $row === null ? $row : self::normalize_group($row, $event_id);
    }

    public static function count_groups($event_id, $status = null)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if ($status !== null && (!is_string($status) || !in_array($status, self::GROUP_STATUSES, true))) {
            return self::invalid_filter();
        }
        $table = self::table('groups');
        if ($table instanceof WP_Error) return $table;
        $where = 'event_id = %d';
        $args = [$event_id];
        if ($status !== null) {
            $where .= ' AND status = %s';
            $args[] = $status;
        }
        return self::read_count("SELECT COUNT(*) FROM $table WHERE $where", $args);
    }

    public static function get_membership($event_id, $membership_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($membership_id)) return self::invalid_input();
        return self::get_membership_scoped($event_id, $membership_id, true);
    }

    public static function get_membership_for_user($event_id, $user_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($user_id)) return self::invalid_input();
        $table = self::table('memberships');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row(
            "SELECT * FROM $table WHERE event_id = %d AND user_id = %d LIMIT 2",
            [$event_id, $user_id]
        );
        return $row instanceof WP_Error || $row === null ? $row : self::normalize_membership($row, $event_id);
    }

    public static function list_memberships($event_id, $filters = [], $page = 1, $per_page = self::DEFAULT_PER_PAGE)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        $pagination = self::validate_pagination($page, $per_page);
        if ($pagination instanceof WP_Error) return $pagination;
        if (!is_array($filters) || !self::only_filters($filters, ['status', 'role'])) return self::invalid_filter();

        $where = ['event_id = %d'];
        $args = [$event_id];
        foreach (['status' => self::MEMBERSHIP_STATUSES, 'role' => self::MEMBERSHIP_ROLES] as $key => $allowed) {
            if (!array_key_exists($key, $filters)) continue;
            if (!is_string($filters[$key]) || !in_array($filters[$key], $allowed, true)) return self::invalid_filter();
            $where[] = "$key = %s";
            $args[] = $filters[$key];
        }

        $table = self::table('memberships');
        if ($table instanceof WP_Error) return $table;
        return self::paginate(
            $table,
            implode(' AND ', $where),
            $args,
            'ORDER BY id ASC',
            $pagination,
            function ($row) use ($event_id) { return self::normalize_membership($row, $event_id); }
        );
    }

    /**
     * H1C-W9: Owner/Admin-facing read of the memberships in one event that
     * already match the binding Additional Inviter predicate (status =
     * active, role = manager, allocated_quota IS NOT NULL). Deliberately
     * NOT built on top of list_memberships()'s generic ['status','role']
     * filters — allocated_quota is an H1C-Additional-Inviter-specific
     * concept, not a generic membership filter, and folding it into
     * list_memberships() would both widen that generic method's contract
     * and make pagination counts wrong for ordinary (non-quota) callers.
     * Returns ONLY membership rows (id/user_id/role/status/allocated_quota/
     * timestamps) via the existing normalize_membership() — no group
     * association, no display_name, no email. Group association and quota
     * arithmetic are resolved by the caller (PGE_Additional_Inviter, via
     * its existing resolve_quota_status()), never by this Repository.
     */
    public static function list_additional_inviter_memberships($event_id, $page = 1, $per_page = self::DEFAULT_PER_PAGE)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        $pagination = self::validate_pagination($page, $per_page);
        if ($pagination instanceof WP_Error) return $pagination;

        $table = self::table('memberships');
        if ($table instanceof WP_Error) return $table;
        return self::paginate(
            $table,
            'event_id = %d AND status = %s AND role = %s AND allocated_quota IS NOT NULL',
            [$event_id, 'active', 'manager'],
            'ORDER BY id ASC',
            $pagination,
            function ($row) use ($event_id) { return self::normalize_membership($row, $event_id); }
        );
    }

    /**
     * H1C-W9: cross-event self-discoverability read — every membership
     * belonging to $user_id, across ALL events, that already matches the
     * same Additional Inviter predicate as list_additional_inviter_
     * memberships() above. Deliberately NOT event-scoped: guard_event()
     * does not apply here (there is no single $event_id to check against
     * a post type), and this method takes no event_id parameter of any
     * kind — the only scoping input is $user_id, which the caller
     * (PGE_Additional_Inviter) is required to source exclusively from the
     * authenticated actor, never from client-supplied input.
     */
    public static function list_additional_inviter_memberships_for_user($user_id, $page = 1, $per_page = self::DEFAULT_PER_PAGE)
    {
        if (!class_exists('PGE_Event_Access_Schema')
            || !method_exists('PGE_Event_Access_Schema', 'is_ready')
            || !PGE_Event_Access_Schema::is_ready()) {
            return new WP_Error('schema_not_ready', 'Event access storage is not ready.');
        }
        if (!self::valid_id($user_id)) return self::invalid_input();
        $pagination = self::validate_pagination($page, $per_page);
        if ($pagination instanceof WP_Error) return $pagination;

        $table = self::table('memberships');
        if ($table instanceof WP_Error) return $table;
        return self::paginate(
            $table,
            'user_id = %d AND status = %s AND role = %s AND allocated_quota IS NOT NULL',
            [$user_id, 'active', 'manager'],
            'ORDER BY event_id ASC, id ASC',
            $pagination,
            function ($row) { return self::normalize_membership($row, (int) ($row['event_id'] ?? 0)); }
        );
    }

    public static function list_group_ids_for_membership($event_id, $membership_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($membership_id)) return self::invalid_input();
        $membership = self::get_membership_scoped($event_id, $membership_id, true);
        if ($membership instanceof WP_Error) return $membership;

        $access = self::table('access');
        $groups = self::table('groups');
        if ($access instanceof WP_Error || $groups instanceof WP_Error) return self::database_error();
        $rows = self::read_results(
            "SELECT a.event_id, a.group_id, g.event_id AS related_event_id FROM $access a LEFT JOIN $groups g ON g.id = a.group_id WHERE a.event_id = %d AND a.membership_id = %d ORDER BY a.group_id ASC",
            [$event_id, $membership_id]
        );
        if ($rows instanceof WP_Error) return $rows;
        return self::normalize_scoped_ids($rows, $event_id, 'group_id');
    }

    public static function list_membership_ids_for_group($event_id, $group_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($group_id)) return self::invalid_input();
        $group = self::get_group_scoped($event_id, $group_id, true);
        if ($group instanceof WP_Error) return $group;

        $access = self::table('access');
        $memberships = self::table('memberships');
        if ($access instanceof WP_Error || $memberships instanceof WP_Error) return self::database_error();
        $rows = self::read_results(
            "SELECT a.event_id, a.membership_id, m.event_id AS related_event_id FROM $access a LEFT JOIN $memberships m ON m.id = a.membership_id WHERE a.event_id = %d AND a.group_id = %d ORDER BY a.membership_id ASC",
            [$event_id, $group_id]
        );
        if ($rows instanceof WP_Error) return $rows;
        return self::normalize_scoped_ids($rows, $event_id, 'membership_id');
    }

    public static function membership_has_group_access($event_id, $membership_id, $group_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($membership_id) || !self::valid_id($group_id)) return self::invalid_input();
        $membership = self::get_membership_scoped($event_id, $membership_id, true);
        if ($membership instanceof WP_Error) return $membership;
        $group = self::get_group_scoped($event_id, $group_id, true);
        if ($group instanceof WP_Error) return $group;

        $access = self::table('access');
        if ($access instanceof WP_Error) return $access;
        $row = self::read_optional_row(
            "SELECT event_id, membership_id, group_id FROM $access WHERE event_id = %d AND membership_id = %d AND group_id = %d LIMIT 2",
            [$event_id, $membership_id, $group_id]
        );
        if ($row instanceof WP_Error) return $row;
        if ($row === null) return false;
        $row_event = self::db_positive_int($row['event_id'] ?? null);
        $row_membership = self::db_positive_int($row['membership_id'] ?? null);
        $row_group = self::db_positive_int($row['group_id'] ?? null);
        if ($row_event === null || $row_membership === null || $row_group === null) return self::database_error();
        if ($row_event !== $event_id) return self::cross_event();
        if ($row_membership !== $membership_id || $row_group !== $group_id) return self::database_error();
        return true;
    }

    public static function get_guest_assignment($event_id, $guest_phone)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        $phone = self::normalize_phone_input($guest_phone);
        if ($phone instanceof WP_Error) return $phone;
        $assignments = self::table('assignments');
        $groups = self::table('groups');
        if ($assignments instanceof WP_Error || $groups instanceof WP_Error) return self::database_error();
        $row = self::read_optional_row(
            "SELECT a.*, g.event_id AS related_event_id FROM $assignments a LEFT JOIN $groups g ON g.id = a.group_id WHERE a.event_id = %d AND a.guest_phone = %s LIMIT 2",
            [$event_id, $phone]
        );
        return $row instanceof WP_Error || $row === null ? $row : self::normalize_assignment($row, $event_id);
    }

    public static function list_group_assignments($event_id, $group_id, $page = 1, $per_page = self::DEFAULT_PER_PAGE)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($group_id)) return self::invalid_input();
        $pagination = self::validate_pagination($page, $per_page);
        if ($pagination instanceof WP_Error) return $pagination;
        $group = self::get_group_scoped($event_id, $group_id, true);
        if ($group instanceof WP_Error) return $group;

        $assignments = self::table('assignments');
        $groups = self::table('groups');
        if ($assignments instanceof WP_Error || $groups instanceof WP_Error) return self::database_error();
        return self::paginate(
            "$assignments a LEFT JOIN $groups g ON g.id = a.group_id",
            'a.event_id = %d AND a.group_id = %d',
            [$event_id, $group_id],
            'ORDER BY a.id ASC',
            $pagination,
            function ($row) use ($event_id) { return self::normalize_assignment($row, $event_id); },
            'a.*, g.event_id AS related_event_id'
        );
    }

    /**
     * Read-only, multi-group counterpart to list_group_assignments().
     *
     * Added for Phase H1C-A2 (H1B Authorization Core) so a collaborator's
     * scoped guest read can be answered with one bounded, indexed query
     * instead of either an N+1 loop over list_group_assignments() per
     * granted group or a "load every guest then filter in PHP" pattern.
     * Strictly read-only: no actor, no WP session/capability/nonce logic,
     * no schema change. $group_ids must already be resolved and trusted by
     * the caller (e.g. an actor's granted_group_ids) — a group id that does
     * not belong to $event_id simply matches zero rows here, it is not an
     * error, since a.event_id = %d already scopes every candidate row to
     * this event before the IN(...) filter is applied.
     */
    public static function list_group_assignments_for_groups($event_id, array $group_ids, $page = 1, $per_page = self::DEFAULT_PER_PAGE)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::is_list($group_ids) || $group_ids === [] || count($group_ids) > self::MAX_GROUP_BATCH) {
            return self::invalid_input();
        }
        $ids = [];
        $seen = [];
        foreach ($group_ids as $group_id) {
            if (!self::valid_id($group_id)) return self::invalid_input();
            if (isset($seen[$group_id])) continue;
            $seen[$group_id] = true;
            $ids[] = $group_id;
        }
        $pagination = self::validate_pagination($page, $per_page);
        if ($pagination instanceof WP_Error) return $pagination;

        $assignments = self::table('assignments');
        $groups = self::table('groups');
        if ($assignments instanceof WP_Error || $groups instanceof WP_Error) return self::database_error();
        $placeholders = implode(', ', array_fill(0, count($ids), '%d'));
        return self::paginate(
            "$assignments a LEFT JOIN $groups g ON g.id = a.group_id",
            "a.event_id = %d AND a.group_id IN ($placeholders)",
            array_merge([$event_id], $ids),
            'ORDER BY a.id ASC',
            $pagination,
            function ($row) use ($event_id) { return self::normalize_assignment($row, $event_id); },
            'a.*, g.event_id AS related_event_id'
        );
    }

    public static function count_group_assignments($event_id, $group_id)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!self::valid_id($group_id)) return self::invalid_input();
        $group = self::get_group_scoped($event_id, $group_id, true);
        if ($group instanceof WP_Error) return $group;
        $table = self::table('assignments');
        if ($table instanceof WP_Error) return $table;
        return self::read_count(
            "SELECT COUNT(*) FROM $table WHERE event_id = %d AND group_id = %d",
            [$event_id, $group_id]
        );
    }

    /**
     * Map a bounded phone list to a list of typed assignment records.
     *
     * The public result is list<array{guest_phone:string,group_id:int}> rather
     * than an associative phone map because PHP coerces numeric-string keys.
     */
    public static function map_guest_groups($event_id, $guest_phones)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        if (!is_array($guest_phones) || !self::is_list($guest_phones) || count($guest_phones) > self::MAX_PHONE_BATCH) {
            return self::invalid_input();
        }

        $phones = [];
        $seen = [];
        foreach ($guest_phones as $value) {
            $phone = self::normalize_phone_input($value);
            if ($phone instanceof WP_Error) return $phone;
            $lookup_key = 'phone:' . $phone;
            if (isset($seen[$lookup_key])) continue;
            $seen[$lookup_key] = true;
            $phones[] = $phone;
        }
        if (!$phones) return [];

        $assignments = self::table('assignments');
        $groups = self::table('groups');
        if ($assignments instanceof WP_Error || $groups instanceof WP_Error) return self::database_error();
        $placeholders = implode(', ', array_fill(0, count($phones), '%s'));
        $rows = self::read_results(
            "SELECT a.*, g.event_id AS related_event_id FROM $assignments a LEFT JOIN $groups g ON g.id = a.group_id WHERE a.event_id = %d AND a.guest_phone IN ($placeholders) ORDER BY a.id ASC",
            array_merge([$event_id], $phones)
        );
        if ($rows instanceof WP_Error) return $rows;

        $found = [];
        foreach ($rows as $row) {
            $normalized = self::normalize_assignment($row, $event_id);
            if ($normalized instanceof WP_Error) return $normalized;
            $phone = $normalized['guest_phone'];
            $lookup_key = 'phone:' . $phone;
            if (!isset($seen[$lookup_key]) || array_key_exists($lookup_key, $found)) return self::database_error();
            $found[$lookup_key] = $normalized['group_id'];
        }

        // Return a list of typed records. A normalized phone cannot safely be
        // a PHP array key because an all-digit value may be coerced to int.
        $map = [];
        foreach ($phones as $phone) {
            $lookup_key = 'phone:' . $phone;
            if (array_key_exists($lookup_key, $found)) {
                $map[] = [
                    'guest_phone' => $phone,
                    'group_id' => $found[$lookup_key],
                ];
            }
        }
        return $map;
    }

    public static function list_audit($event_id, $filters = [], $page = 1, $per_page = self::DEFAULT_PER_PAGE)
    {
        $guard = self::guard_event($event_id);
        if ($guard instanceof WP_Error) return $guard;
        $pagination = self::validate_pagination($page, $per_page);
        if ($pagination instanceof WP_Error) return $pagination;
        $allowed_filters = ['action', 'entity_type', 'actor_user_id', 'entity_id'];
        if (!is_array($filters) || !self::only_filters($filters, $allowed_filters)) return self::invalid_filter();

        $where = ['event_id = %d'];
        $args = [$event_id];
        if (array_key_exists('action', $filters)) {
            $action = $filters['action'];
            if (!is_string($action) || $action === '' || strlen($action) > 40 || !in_array($action, self::AUDIT_ACTIONS, true)) {
                return self::invalid_filter();
            }
            $where[] = 'action = %s';
            $args[] = $action;
        }
        if (array_key_exists('entity_type', $filters)) {
            $type = $filters['entity_type'];
            if (!is_string($type) || !in_array($type, self::AUDIT_ENTITY_TYPES, true)) return self::invalid_filter();
            $where[] = 'entity_type = %s';
            $args[] = $type;
        }
        foreach (['actor_user_id', 'entity_id'] as $key) {
            if (!array_key_exists($key, $filters)) continue;
            if (!self::valid_id($filters[$key])) return self::invalid_filter();
            $where[] = "$key = %d";
            $args[] = $filters[$key];
        }

        $table = self::table('audit');
        if ($table instanceof WP_Error) return $table;
        return self::paginate(
            $table,
            implode(' AND ', $where),
            $args,
            'ORDER BY created_at DESC, id DESC',
            $pagination,
            function ($row) use ($event_id) { return self::normalize_audit($row, $event_id); }
        );
    }

    private static function normalize_group_name_input($value)
    {
        if (!is_string($value) || preg_match('//u', $value) !== 1) {
            return self::invalid_name();
        }
        if (strpos($value, '<') !== false || strpos($value, '>') !== false
            || preg_match('/[\p{Cf}\p{Co}\x{0000}-\x{0008}\x{000B}\x{000C}\x{000E}-\x{001F}\x{007F}-\x{009F}]/u', $value) === 1) {
            return self::invalid_name();
        }
        $whitespace = '[\p{Z}\x{0009}\x{000A}\x{000D}]';
        $name = preg_replace('/\A' . $whitespace . '+|' . $whitespace . '+\z/u', '', $value);
        $name = is_string($name) ? preg_replace('/' . $whitespace . '+/u', ' ', $name) : null;
        if (!is_string($name) || $name === '') return self::invalid_name();

        $name_length = self::unicode_codepoint_length($name);
        if ($name_length === null || $name_length > 191) return self::invalid_name();
        $name_key = strtr($name, array_combine(range('A', 'Z'), range('a', 'z')));
        $key_length = self::unicode_codepoint_length($name_key);
        if ($name_key === '' || $key_length === null || $key_length > 160) return self::invalid_name();
        return ['name' => $name, 'name_key' => $name_key];
    }

    private static function unicode_codepoint_length($value)
    {
        $matched = preg_match_all('/./us', $value, $unused);
        return is_int($matched) && $matched >= 0 ? $matched : null;
    }

    private static function with_group_transaction($event_id, $operation)
    {
        return self::with_event_transaction(function () use ($event_id, $operation) {
            $groups = self::lock_groups($event_id);
            if ($groups instanceof WP_Error) return $groups;
            $result = call_user_func($operation, $groups);
            if (!($result instanceof WP_Error)
                && (!is_array($result) || !array_key_exists('changed', $result) || !array_key_exists('group', $result))) {
                return self::database_error();
            }
            return $result;
        });
    }

    private static function with_event_transaction($operation)
    {
        global $wpdb;
        if (!is_callable($operation)) return self::database_error();
        $previous_error = isset($wpdb->last_error) ? $wpdb->last_error : '';
        $wpdb->last_error = '';
        $started = false;
        try {
            $begin = self::control_query('START TRANSACTION');
            if ($begin instanceof WP_Error) return $begin;
            $started = true;

            $result = call_user_func($operation);
            if ($result instanceof WP_Error) {
                self::rollback_transaction();
                $started = false;
                return $result;
            }
            if (!is_array($result) || !array_key_exists('changed', $result)) {
                self::rollback_transaction();
                $started = false;
                return self::database_error();
            }
            $commit = self::control_query('COMMIT');
            if ($commit instanceof WP_Error) {
                self::rollback_transaction();
                $started = false;
                return self::database_error();
            }
            $started = false;
            return $result;
        } catch (Throwable $e) {
            if ($started) self::rollback_transaction();
            return self::database_error();
        } finally {
            $wpdb->last_error = $previous_error;
        }
    }

    private static function control_query($sql)
    {
        global $wpdb;
        $previous_error = isset($wpdb->last_error) ? $wpdb->last_error : '';
        $wpdb->last_error = '';
        try {
            $result = $wpdb->query($sql);
        } catch (Throwable $e) {
            $wpdb->last_error = $previous_error;
            return self::database_error();
        }
        $query_error = (string) $wpdb->last_error;
        $wpdb->last_error = $previous_error;
        if ($query_error !== '' || !is_int($result) || $result !== 0) {
            return self::database_error();
        }
        return true;
    }

    private static function rollback_transaction()
    {
        self::control_query('ROLLBACK');
    }

    private static function mutation_query($sql, array $args)
    {
        global $wpdb;
        $query = self::prepare_query($sql, $args);
        if ($query instanceof WP_Error) return $query;
        $previous_error = isset($wpdb->last_error) ? $wpdb->last_error : '';
        $wpdb->last_error = '';
        try {
            $result = $wpdb->query($query);
        } catch (Throwable $e) {
            $wpdb->last_error = $previous_error;
            return self::database_error();
        }
        $query_error = (string) $wpdb->last_error;
        $wpdb->last_error = $previous_error;
        return $query_error === '' && is_int($result) && $result >= 0 ? $result : self::database_error();
    }

    private static function delete_rows($table, array $where, array $formats)
    {
        global $wpdb;
        $previous_error = isset($wpdb->last_error) ? $wpdb->last_error : '';
        $wpdb->last_error = '';
        try {
            $result = $wpdb->delete($table, $where, $formats);
        } catch (Throwable $e) {
            $wpdb->last_error = $previous_error;
            return self::database_error();
        }
        $query_error = (string) $wpdb->last_error;
        $wpdb->last_error = $previous_error;
        return $query_error === '' && is_int($result) && $result >= 0 ? $result : self::database_error();
    }

    private static function normalize_locked_groups(array $rows, $event_id)
    {
        $groups = [];
        $seen = [];
        foreach ($rows as $row) {
            $group = self::normalize_group($row, $event_id);
            if ($group instanceof WP_Error || isset($seen[$group['id']])) return self::database_error();
            $seen[$group['id']] = true;
            $groups[] = $group;
        }
        return $groups;
    }

    private static function lock_groups($event_id)
    {
        $table = self::table('groups');
        if ($table instanceof WP_Error) return $table;
        $rows = self::read_results("SELECT * FROM $table WHERE event_id = %d ORDER BY id FOR UPDATE", [$event_id]);
        return $rows instanceof WP_Error ? $rows : self::normalize_locked_groups($rows, $event_id);
    }

    private static function lock_memberships($event_id)
    {
        $table = self::table('memberships');
        if ($table instanceof WP_Error) return $table;
        $rows = self::read_results("SELECT * FROM $table WHERE event_id = %d ORDER BY id FOR UPDATE", [$event_id]);
        if ($rows instanceof WP_Error) return $rows;
        $out = []; $seen_ids = []; $seen_users = [];
        foreach ($rows as $row) {
            $membership = self::normalize_membership($row, $event_id);
            if ($membership instanceof WP_Error || isset($seen_ids[$membership['id']]) || isset($seen_users[$membership['user_id']])) return self::database_error();
            $seen_ids[$membership['id']] = true; $seen_users[$membership['user_id']] = true; $out[] = $membership;
        }
        return $out;
    }

    private static function lock_membership_access($event_id, $membership_id)
    {
        $table = self::table('access');
        if ($table instanceof WP_Error) return $table;
        $rows = self::read_results("SELECT * FROM $table WHERE event_id = %d AND membership_id = %d ORDER BY id FOR UPDATE", [$event_id, $membership_id]);
        if ($rows instanceof WP_Error) return $rows;
        $out = []; $seen = [];
        foreach ($rows as $row) {
            $access = self::normalize_access($row, $event_id, $membership_id);
            if ($access instanceof WP_Error || isset($seen[$access['id']]) || isset($seen['g:' . $access['group_id']])) return self::database_error();
            $seen[$access['id']] = true; $seen['g:' . $access['group_id']] = true; $out[] = $access;
        }
        return $out;
    }

    /**
     * H1C-W8 Fix Pass — Additional Inviter group exclusivity. Locks every
     * access row for a single GROUP (across all memberships that hold it),
     * the mirror-image of lock_membership_access() (which locks every
     * access row for a single MEMBERSHIP across all groups it holds).
     * FOR UPDATE, same convention as every other lock_* helper in this
     * class — callers must already hold with_event_transaction().
     */
    private static function lock_group_access($event_id, $group_id)
    {
        $table = self::table('access');
        if ($table instanceof WP_Error) return $table;
        $rows = self::read_results("SELECT * FROM $table WHERE event_id = %d AND group_id = %d ORDER BY id FOR UPDATE", [$event_id, $group_id]);
        if ($rows instanceof WP_Error) return $rows;
        $out = []; $seen = [];
        foreach ($rows as $row) {
            $access = self::normalize_access($row, $event_id, null, $group_id);
            if ($access instanceof WP_Error || isset($seen[$access['id']])) return self::database_error();
            $seen[$access['id']] = true; $out[] = $access;
        }
        return $out;
    }

    /**
     * H1C-W8 Fix Pass — Additional Inviter group exclusivity invariant:
     * ONE GROUP -> AT MOST ONE ACTIVE, quota-enabled (allocated_quota IS
     * NOT NULL, role=manager, status=active) Additional Inviter. This is
     * an Additional-Inviter-specific rule ONLY — it does not restrict how
     * many ordinary (non-quota) H1C memberships share a group, which stays
     * exactly as unrestricted as it always has been (W1-W7 unchanged).
     *
     * Shared by the three Repository call sites that can put a
     * quota-enabled membership onto a group: create_additional_inviter_
     * membership(), set_membership_quota() (when raising a membership to
     * quota-enabled), and reactivate_membership() (when reactivating a
     * membership that already carries a quota and still holds group
     * access). $locked_memberships must already be the caller's
     * lock_memberships() result for this event (same transaction, same
     * lock) — this helper does not lock memberships itself, only the
     * group's access rows, to avoid re-locking what the caller already
     * holds.
     *
     * @param array $locked_memberships Result of lock_memberships($event_id).
     * @param int $group_id Group to check for an existing active quota inviter.
     * @param int|null $except_membership_id Exclude this membership from the
     *        conflict check (the membership being created/updated/reactivated
     *        itself, when it may already legitimately hold this group).
     * @return WP_Error|null WP_Error('quota_group_conflict', ...) if another
     *         active quota-enabled inviter already holds this group; null if
     *         no conflict.
     */
    private static function ensure_no_active_quota_inviter_for_group($event_id, array $locked_memberships, $group_id, $except_membership_id = null)
    {
        $group_access = self::lock_group_access($event_id, $group_id);
        if ($group_access instanceof WP_Error) return $group_access;
        foreach ($group_access as $access) {
            $candidate_id = $access['membership_id'];
            if ($except_membership_id !== null && $candidate_id === $except_membership_id) continue;
            $candidate = self::find_locked_membership_by_id($locked_memberships, $candidate_id);
            // An access row referencing a membership not present in this
            // event's own locked membership set is a storage-integrity
            // failure, not a "no conflict" — fail closed rather than skip.
            if ($candidate === null) return self::database_error();
            if ($candidate['status'] === 'active' && $candidate['role'] === 'manager' && $candidate['allocated_quota'] !== null) {
                return self::quota_group_conflict();
            }
        }
        return null;
    }

    /**
     * H1C-W8 Fix Pass 2 (Mutation-Closure Audit) — shared guard for every
     * remaining mutation path that can cause a membership to newly satisfy
     * the Additional-Inviter predicate (status=active AND role=manager AND
     * allocated_quota IS NOT NULL): grant_group_access() and
     * change_membership_role(). (create_additional_inviter_membership()
     * and set_membership_quota() already enforce this directly, from Fix
     * Pass 1 — deliberately left untouched here, not routed through this
     * helper, to avoid an unnecessary refactor of already-verified code.)
     *
     * $membership is the CANDIDATE'S state as it would be AFTER the
     * mutation under evaluation (e.g. with 'role' already set to the new
     * role for change_membership_role()) — never the pre-mutation row.
     * $additional_group_id is a group about to be granted that is NOT yet
     * reflected in the membership's locked access rows (grant_group_
     * access()'s own target group); pass null when the mutation does not
     * itself add a group (change_membership_role()), so only the
     * membership's EXISTING access rows are considered.
     *
     * Enforces, ONLY when the resulting membership is a quota-enabled
     * candidate: exactly one granted group (the MVP one-group-per-inviter
     * rule — 0 or >1 both fail closed with invalid_state(), matching the
     * exact shape guard set_membership_quota() already uses), and the
     * group-exclusivity invariant on that one group via the existing
     * ensure_no_active_quota_inviter_for_group(). A non-candidate
     * membership (allocated_quota IS NULL, or not an active manager) is
     * entirely unrestricted — generic H1C behavior is unchanged.
     *
     * @return WP_Error|null
     */
    private static function guard_quota_inviter_shape($event_id, array $locked_memberships, array $membership, $additional_group_id = null)
    {
        if ($membership['status'] !== 'active' || $membership['role'] !== 'manager' || $membership['allocated_quota'] === null) {
            return null;
        }
        $access_rows = self::lock_membership_access($event_id, $membership['id']);
        if ($access_rows instanceof WP_Error) return $access_rows;
        $group_ids = array_map(fn($row) => (int) $row['group_id'], $access_rows);
        if ($additional_group_id !== null) $group_ids[] = (int) $additional_group_id;
        $group_ids = array_values(array_unique($group_ids));
        if (count($group_ids) !== 1) return self::invalid_state();
        return self::ensure_no_active_quota_inviter_for_group($event_id, $locked_memberships, $group_ids[0], (int) $membership['id']);
    }

    private static function lock_access_relation($event_id, $membership_id, $group_id)
    {
        $table = self::table('access');
        if ($table instanceof WP_Error) return $table;
        $rows = self::read_results("SELECT * FROM $table WHERE event_id = %d AND membership_id = %d AND group_id = %d ORDER BY id FOR UPDATE", [$event_id, $membership_id, $group_id]);
        if ($rows instanceof WP_Error) return $rows;
        if (count($rows) > 1) return self::database_error();
        if (!$rows) return null;
        $access = self::normalize_access($rows[0], $event_id, $membership_id, $group_id);
        return $access instanceof WP_Error ? self::write_storage_error($access) : $access;
    }

    private static function lock_guest_assignment($event_id, $phone)
    {
        $table = self::table('assignments');
        if ($table instanceof WP_Error) return $table;
        $rows = self::read_results(
            "SELECT * FROM $table WHERE event_id = %d AND guest_phone = %s ORDER BY id FOR UPDATE",
            [$event_id, $phone]
        );
        if ($rows instanceof WP_Error) return $rows;
        if (count($rows) > 1) return self::database_error();
        if (!$rows) return null;
        return self::normalize_write_assignment($rows[0], $event_id, $phone);
    }

    private static function find_locked_membership_by_id(array $memberships, $id)
    {
        foreach ($memberships as $membership) if ($membership['id'] === $id) return $membership;
        return null;
    }

    private static function find_locked_membership_by_user(array $memberships, $user_id)
    {
        foreach ($memberships as $membership) if ($membership['user_id'] === $user_id) return $membership;
        return null;
    }

    private static function find_locked_group_by_id(array $groups, $group_id)
    {
        foreach ($groups as $group) {
            if ($group['id'] === $group_id) return $group;
        }
        return null;
    }

    private static function find_locked_group_by_key(array $groups, $name_key, $except_id = null)
    {
        foreach ($groups as $group) {
            if ($group['status'] === 'active' && $group['name_key'] === $name_key && $group['id'] !== $except_id) return $group;
        }
        return null;
    }

    private static function locked_default_group(array $groups)
    {
        $default = null;
        foreach ($groups as $group) {
            if (!$group['is_default']) continue;
            if ($default !== null || $group['status'] !== 'active') return self::database_error();
            $default = $group;
        }
        return $default;
    }

    private static function update_group_default_slot($event_id, $group_id, $slot, $now)
    {
        $table = self::table('groups');
        if ($table instanceof WP_Error) return $table;
        if ($slot === null) {
            $result = self::mutation_query(
                "UPDATE $table SET default_slot = NULL, updated_at = %s WHERE event_id = %d AND id = %d AND status = %s AND default_slot = %d",
                [$now, $event_id, $group_id, 'active', 1]
            );
        } else {
            $result = self::mutation_query(
                "UPDATE $table SET default_slot = %d, updated_at = %s WHERE event_id = %d AND id = %d AND status = %s AND default_slot IS NULL",
                [1, $now, $event_id, $group_id, 'active']
            );
        }
        if ($result instanceof WP_Error) return $result;
        if ($result === 1) return true;
        return $result === 0 ? self::concurrent_update() : self::database_error();
    }

    private static function insert_group_audit($event_id, $actor_user_id, $action, $group_id, $metadata, $now)
    {
        return self::insert_audit($event_id, $actor_user_id, $action, 'group', $group_id, $metadata, $now);
    }

    private static function insert_audit($event_id, $actor_user_id, $action, $entity_type, $entity_id, $metadata, $now)
    {
        $pairs = [
            'group_created' => 'group', 'group_renamed' => 'group', 'default_group_changed' => 'group', 'group_archived' => 'group',
            'membership_created' => 'membership', 'membership_role_changed' => 'membership', 'membership_revoked' => 'membership', 'membership_reactivated' => 'membership', 'membership_quota_changed' => 'membership',
            'group_access_granted' => 'group_access', 'group_access_revoked' => 'group_access',
            'guest_group_assigned' => 'guest_assignment', 'guest_group_moved' => 'guest_assignment', 'guest_group_unassigned' => 'guest_assignment',
        ];
        if (($pairs[$action] ?? null) !== $entity_type || !self::valid_id($actor_user_id) || !self::valid_id($entity_id)) {
            return self::database_error();
        }
        if (strpos($action, 'guest_group_') === 0) {
            $metadata = self::normalize_guest_audit_metadata($action, $metadata);
            if ($metadata instanceof WP_Error) return $metadata;
        }
        $table = self::table('audit');
        if ($table instanceof WP_Error) return $table;
        if ($metadata === null) {
            $result = self::mutation_query(
                "INSERT INTO $table (event_id, actor_user_id, action, entity_type, entity_id, metadata, created_at) VALUES (%d, %d, %s, %s, %d, NULL, %s)",
                [$event_id, $actor_user_id, $action, $entity_type, $entity_id, $now]
            );
        } else {
            if (!is_array($metadata) || self::is_list($metadata) || !function_exists('wp_json_encode')) return self::database_error();
            $json = wp_json_encode($metadata);
            if (!is_string($json) || $json === '') return self::database_error();
            $result = self::mutation_query(
                "INSERT INTO $table (event_id, actor_user_id, action, entity_type, entity_id, metadata, created_at) VALUES (%d, %d, %s, %s, %d, %s, %s)",
                [$event_id, $actor_user_id, $action, $entity_type, $entity_id, $json, $now]
            );
        }
        if ($result instanceof WP_Error) return $result;
        return $result === 1 ? true : self::database_error();
    }

    private static function read_group_inside_transaction($event_id, $group_id)
    {
        $table = self::table('groups');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row("SELECT * FROM $table WHERE event_id = %d AND id = %d LIMIT 2", [$event_id, $group_id]);
        if ($row instanceof WP_Error) return $row;
        if ($row === null) return self::database_error();
        return self::normalize_group($row, $event_id);
    }

    private static function read_membership_inside_transaction($event_id, $membership_id)
    {
        $table = self::table('memberships');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row("SELECT * FROM $table WHERE event_id = %d AND id = %d LIMIT 2", [$event_id, $membership_id]);
        if ($row instanceof WP_Error || $row === null) return self::database_error();
        $membership = self::normalize_membership($row, $event_id);
        return $membership instanceof WP_Error ? self::write_storage_error($membership) : $membership;
    }

    private static function read_membership_for_user_inside_transaction($event_id, $user_id)
    {
        $table = self::table('memberships');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row("SELECT * FROM $table WHERE event_id = %d AND user_id = %d LIMIT 2", [$event_id, $user_id]);
        if ($row instanceof WP_Error || $row === null) return $row;
        $membership = self::normalize_membership($row, $event_id);
        return $membership instanceof WP_Error ? self::write_storage_error($membership) : $membership;
    }

    private static function read_access_relation_inside_transaction($event_id, $membership_id, $group_id)
    {
        $table = self::table('access');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row("SELECT * FROM $table WHERE event_id = %d AND membership_id = %d AND group_id = %d LIMIT 2", [$event_id, $membership_id, $group_id]);
        if ($row instanceof WP_Error || $row === null) return $row;
        $access = self::normalize_access($row, $event_id, $membership_id, $group_id);
        return $access instanceof WP_Error ? self::write_storage_error($access) : $access;
    }

    private static function read_assignment_inside_transaction($event_id, $phone)
    {
        $table = self::table('assignments');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row(
            "SELECT * FROM $table WHERE event_id = %d AND guest_phone = %s ORDER BY id LIMIT 2",
            [$event_id, $phone]
        );
        if ($row instanceof WP_Error || $row === null) return $row;
        return self::normalize_write_assignment($row, $event_id, $phone);
    }

    private static function validate_assignment_group_reference(array $assignment, array $groups, $event_id)
    {
        $group = self::find_locked_group_by_id($groups, $assignment['group_id']);
        if ($group !== null) return $group;

        $table = self::table('groups');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row("SELECT event_id FROM $table WHERE id = %d LIMIT 2", [$assignment['group_id']]);
        if ($row instanceof WP_Error) return $row;
        if ($row === null) return 'missing';
        $related_event = self::db_positive_int($row['event_id'] ?? null);
        if ($related_event === null || $related_event !== $event_id) return self::database_error();
        return self::database_error();
    }

    private static function assignment_matches_create(array $assignment, $assignment_id, $event_id, $phone, $group_id, $actor_user_id, $now)
    {
        return $assignment['id'] === $assignment_id && $assignment['event_id'] === $event_id
            && $assignment['guest_phone'] === $phone && $assignment['group_id'] === $group_id
            && $assignment['assigned_by_user_id'] === $actor_user_id
            && $assignment['created_at'] === $now && $assignment['updated_at'] === $now;
    }

    private static function assignment_write_result($changed, $assignment_id, $group_id, $has_assignment)
    {
        return [
            'changed' => $changed,
            'assignment_id' => $assignment_id,
            'group_id' => $group_id,
            'has_assignment' => $has_assignment,
        ];
    }

    private static function membership_matches_create(array $membership, $user_id, $role, $actor_user_id, $now)
    {
        return $membership['user_id'] === $user_id && $membership['role'] === $role && $membership['status'] === 'active'
            && $membership['created_by_user_id'] === $actor_user_id && $membership['activated_at'] === $now
            && $membership['revoked_at'] === null && $membership['created_at'] === $now && $membership['updated_at'] === $now;
    }

    private static function translate_duplicate_after_failure($event_id, $name_key, $except_id, $fallback)
    {
        $table = self::table('groups');
        if ($table instanceof WP_Error) return $fallback;
        $row = self::read_optional_row(
            "SELECT * FROM $table WHERE event_id = %d AND name_key = %s AND status = %s LIMIT 2",
            [$event_id, $name_key, 'active']
        );
        if ($row instanceof WP_Error || $row === null) return $fallback;
        $group = self::normalize_group($row, $event_id);
        if ($group instanceof WP_Error) return $fallback;
        return $group['id'] !== $except_id ? self::duplicate_group() : $fallback;
    }

    private static function guard_event($event_id)
    {
        if (!class_exists('PGE_Event_Access_Schema')
            || !method_exists('PGE_Event_Access_Schema', 'is_ready')
            || !PGE_Event_Access_Schema::is_ready()) {
            return new WP_Error('schema_not_ready', 'Event access storage is not ready.');
        }
        if (!self::valid_id($event_id)) return self::invalid_input();
        if (get_post_type($event_id) !== 'pge_event') return self::not_found();
        return true;
    }

    private static function get_group_scoped($event_id, $group_id, $required)
    {
        $table = self::table('groups');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row(
            "SELECT * FROM $table WHERE event_id = %d AND id = %d LIMIT 2",
            [$event_id, $group_id]
        );
        if ($row instanceof WP_Error) return $row;
        if ($row === null) return $required ? self::not_found() : null;
        return self::normalize_group($row, $event_id);
    }

    private static function get_membership_scoped($event_id, $membership_id, $required)
    {
        $table = self::table('memberships');
        if ($table instanceof WP_Error) return $table;
        $row = self::read_optional_row(
            "SELECT * FROM $table WHERE event_id = %d AND id = %d LIMIT 2",
            [$event_id, $membership_id]
        );
        if ($row instanceof WP_Error) return $row;
        if ($row === null) return $required ? self::not_found() : null;
        return self::normalize_membership($row, $event_id);
    }

    private static function paginate($from, $where, array $args, $order, array $pagination, $normalizer, $select = '*')
    {
        $total = self::read_count("SELECT COUNT(*) FROM $from WHERE $where", $args);
        if ($total instanceof WP_Error) return $total;
        $rows = self::read_results(
            "SELECT $select FROM $from WHERE $where $order LIMIT %d OFFSET %d",
            array_merge($args, [$pagination['per_page'], $pagination['offset']])
        );
        if ($rows instanceof WP_Error) return $rows;
        $items = [];
        foreach ($rows as $row) {
            $item = call_user_func($normalizer, $row);
            if ($item instanceof WP_Error) return $item;
            $items[] = $item;
        }
        return [
            'items' => $items,
            'page' => $pagination['page'],
            'per_page' => $pagination['per_page'],
            'total' => $total,
            'total_pages' => $total === 0 ? 0 : intdiv($total - 1, $pagination['per_page']) + 1,
        ];
    }

    private static function validate_pagination($page, $per_page)
    {
        if (!self::valid_id($page) || !self::valid_id($per_page) || $per_page > self::MAX_PER_PAGE) {
            return self::invalid_input();
        }
        $base = $page - 1;
        if ($base > intdiv(PHP_INT_MAX, $per_page)) return self::invalid_input();
        return ['page' => $page, 'per_page' => $per_page, 'offset' => $base * $per_page];
    }

    private static function read_optional_row($sql, array $args)
    {
        $rows = self::read_results($sql, $args);
        if ($rows instanceof WP_Error) return $rows;
        if (count($rows) > 1) return self::database_error();
        return $rows ? $rows[0] : null;
    }

    private static function read_count($sql, array $args)
    {
        $value = self::read_scalar($sql, $args);
        if ($value instanceof WP_Error) return $value;
        $count = self::db_nonnegative_int($value);
        return $count === null ? self::database_error() : $count;
    }

    private static function read_results($sql, array $args)
    {
        global $wpdb;
        $query = self::prepare_query($sql, $args);
        if ($query instanceof WP_Error) return $query;
        $previous_error = isset($wpdb->last_error) ? $wpdb->last_error : '';
        $wpdb->last_error = '';
        try {
            $rows = $wpdb->get_results($query, ARRAY_A);
        } catch (Throwable $e) {
            $wpdb->last_error = $previous_error;
            return self::database_error();
        }
        $query_error = (string) $wpdb->last_error;
        $wpdb->last_error = $previous_error;
        if ($query_error !== '' || !is_array($rows)) return self::database_error();
        foreach ($rows as $row) {
            if (!is_array($row)) return self::database_error();
        }
        return $rows;
    }

    private static function read_scalar($sql, array $args)
    {
        global $wpdb;
        $query = self::prepare_query($sql, $args);
        if ($query instanceof WP_Error) return $query;
        $previous_error = isset($wpdb->last_error) ? $wpdb->last_error : '';
        $wpdb->last_error = '';
        try {
            $value = $wpdb->get_var($query);
        } catch (Throwable $e) {
            $wpdb->last_error = $previous_error;
            return self::database_error();
        }
        $query_error = (string) $wpdb->last_error;
        $wpdb->last_error = $previous_error;
        return $query_error !== '' ? self::database_error() : $value;
    }

    private static function prepare_query($sql, array $args)
    {
        global $wpdb;
        $previous_error = isset($wpdb->last_error) ? $wpdb->last_error : '';
        $wpdb->last_error = '';
        try {
            $query = call_user_func_array([$wpdb, 'prepare'], array_merge([$sql], $args));
        } catch (Throwable $e) {
            $wpdb->last_error = $previous_error;
            return self::database_error();
        }
        $prepare_error = (string) $wpdb->last_error;
        $wpdb->last_error = $previous_error;
        return is_string($query) && $query !== '' && $prepare_error === ''
            ? $query
            : self::database_error();
    }

    private static function table($key)
    {
        global $wpdb;
        $map = [
            'groups' => 'pge_event_invitation_groups',
            'memberships' => 'pge_event_host_memberships',
            'access' => 'pge_event_host_group_access',
            'assignments' => 'pge_invitation_group_assignments',
            'audit' => 'pge_event_access_audit_log',
        ];
        $prefix = isset($wpdb->prefix) && is_string($wpdb->prefix) ? $wpdb->prefix : '';
        if (!isset($map[$key]) || preg_match('/\A[A-Za-z0-9_]+\z/', $prefix) !== 1) return self::database_error();
        return $prefix . $map[$key];
    }

    private static function normalize_group($row, $event_id)
    {
        if (!is_array($row)) return self::database_error();
        foreach (['id', 'event_id', 'name', 'name_key', 'status', 'default_slot', 'created_by_user_id', 'created_at', 'updated_at', 'archived_at'] as $key) {
            if (!array_key_exists($key, $row)) return self::database_error();
        }
        $id = self::db_positive_int($row['id'] ?? null);
        $row_event = self::db_positive_int($row['event_id'] ?? null);
        $creator = self::db_positive_int($row['created_by_user_id'] ?? null);
        $default_slot = $row['default_slot'] ?? null;
        if ($id === null || $row_event === null || $creator === null) return self::database_error();
        if ($row_event !== $event_id) return self::cross_event();
        if (!is_string($row['name'] ?? null)
            || !self::nullable_string($row['name_key'] ?? null)
            || !is_string($row['status'] ?? null)
            || !in_array($row['status'], self::GROUP_STATUSES, true)
            || !self::required_string($row['created_at'] ?? null)
            || !self::required_string($row['updated_at'] ?? null)
            || !self::nullable_string($row['archived_at'] ?? null)) {
            return self::database_error();
        }
        $slot = $default_slot === null ? null : self::db_positive_int($default_slot);
        if ($default_slot !== null && $slot !== 1) return self::database_error();
        if ($row['status'] === 'active'
            && (!is_string($row['name_key']) || $row['name_key'] === '' || $row['archived_at'] !== null)) {
            return self::database_error();
        }
        if ($row['status'] === 'archived'
            && ($row['name_key'] !== null || $slot !== null || !self::required_string($row['archived_at']))) {
            return self::database_error();
        }
        return [
            'id' => $id,
            'event_id' => $row_event,
            'name' => $row['name'],
            'name_key' => $row['name_key'],
            'status' => $row['status'],
            'is_default' => $slot === 1,
            'created_by_user_id' => $creator,
            'created_at' => $row['created_at'],
            'updated_at' => $row['updated_at'],
            'archived_at' => $row['archived_at'],
        ];
    }

    private static function normalize_membership($row, $event_id)
    {
        if (!is_array($row)) return self::database_error();
        foreach (['id', 'event_id', 'user_id', 'role', 'status', 'created_by_user_id', 'activated_at', 'revoked_at', 'created_at', 'updated_at', 'allocated_quota'] as $key) {
            if (!array_key_exists($key, $row)) return self::database_error();
        }
        $id = self::db_positive_int($row['id'] ?? null);
        $row_event = self::db_positive_int($row['event_id'] ?? null);
        $user = self::db_positive_int($row['user_id'] ?? null);
        $creator = self::db_positive_int($row['created_by_user_id'] ?? null);
        if ($id === null || $row_event === null || $user === null || $creator === null) return self::database_error();
        if ($row_event !== $event_id) return self::cross_event();
        if (!is_string($row['role'] ?? null) || !in_array($row['role'], self::MEMBERSHIP_ROLES, true)
            || !is_string($row['status'] ?? null) || !in_array($row['status'], self::MEMBERSHIP_STATUSES, true)
            || !self::required_string($row['activated_at'] ?? null)
            || !self::nullable_string($row['revoked_at'] ?? null)
            || !self::required_string($row['created_at'] ?? null)
            || !self::required_string($row['updated_at'] ?? null)) {
            return self::database_error();
        }
        if (($row['status'] === 'active' && $row['revoked_at'] !== null)
            || ($row['status'] === 'revoked' && !self::required_string($row['revoked_at']))) {
            return self::database_error();
        }
        // H1C-W8: allocated_quota is NULL for every ordinary membership
        // (unchanged W1-W7 shape) or a strict positive integer for an
        // Additional Inviter. Any other stored value (0, negative, a
        // non-numeric string) is a storage-integrity failure, not a valid
        // "unlimited"/"unset" convention — 0 is deliberately never treated
        // as unlimited here (Product Contract Section 8).
        $quota_raw = $row['allocated_quota'];
        if ($quota_raw === null) {
            $quota = null;
        } else {
            $quota = self::db_positive_int($quota_raw);
            if ($quota === null) return self::database_error();
        }
        return [
            'id' => $id,
            'event_id' => $row_event,
            'user_id' => $user,
            'role' => $row['role'],
            'status' => $row['status'],
            'created_by_user_id' => $creator,
            'activated_at' => $row['activated_at'],
            'revoked_at' => $row['revoked_at'],
            'created_at' => $row['created_at'],
            'updated_at' => $row['updated_at'],
            'allocated_quota' => $quota,
        ];
    }

    private static function normalize_access($row, $event_id, $membership_id = null, $group_id = null)
    {
        if (!is_array($row)) return self::database_error();
        foreach (['id', 'event_id', 'membership_id', 'group_id', 'granted_by_user_id', 'created_at'] as $key) if (!array_key_exists($key, $row)) return self::database_error();
        $id = self::db_positive_int($row['id']);
        $row_event = self::db_positive_int($row['event_id']);
        $row_membership = self::db_positive_int($row['membership_id']);
        $row_group = self::db_positive_int($row['group_id']);
        $granter = self::db_positive_int($row['granted_by_user_id']);
        if ($id === null || $row_event === null || $row_membership === null || $row_group === null || $granter === null || !self::required_string($row['created_at'])) return self::database_error();
        if ($row_event !== $event_id) return self::cross_event();
        if (($membership_id !== null && $row_membership !== $membership_id) || ($group_id !== null && $row_group !== $group_id)) return self::database_error();
        return ['id' => $id, 'event_id' => $row_event, 'membership_id' => $row_membership, 'group_id' => $row_group, 'granted_by_user_id' => $granter, 'created_at' => $row['created_at']];
    }

    private static function normalize_write_assignment($row, $event_id, $phone)
    {
        if (!is_array($row)) return self::database_error();
        foreach (['id', 'event_id', 'guest_phone', 'group_id', 'assigned_by_user_id', 'created_at', 'updated_at'] as $key) {
            if (!array_key_exists($key, $row)) return self::database_error();
        }
        $id = self::db_positive_int($row['id']);
        $row_event = self::db_positive_int($row['event_id']);
        $group_id = self::db_positive_int($row['group_id']);
        $actor_id = self::db_positive_int($row['assigned_by_user_id']);
        $stored_phone = $row['guest_phone'];
        $canonical = is_string($stored_phone) && function_exists('pge_event_guests_norm_phone')
            ? pge_event_guests_norm_phone($stored_phone)
            : null;
        if ($id === null || $row_event === null || $group_id === null || $actor_id === null
            || $row_event !== $event_id || !is_string($stored_phone) || $stored_phone !== $phone
            || !is_string($canonical) || $canonical !== $stored_phone || strlen($stored_phone) > 32
            || !self::required_string($row['created_at']) || !self::required_string($row['updated_at'])) {
            return self::database_error();
        }
        return [
            'id' => $id,
            'event_id' => $row_event,
            'guest_phone' => $stored_phone,
            'group_id' => $group_id,
            'assigned_by_user_id' => $actor_id,
            'created_at' => $row['created_at'],
            'updated_at' => $row['updated_at'],
        ];
    }

    private static function normalize_assignment($row, $event_id)
    {
        if (!is_array($row)) return self::database_error();
        foreach (['id', 'event_id', 'guest_phone', 'group_id', 'assigned_by_user_id', 'created_at', 'updated_at', 'related_event_id'] as $key) {
            if (!array_key_exists($key, $row)) return self::database_error();
        }
        $id = self::db_positive_int($row['id'] ?? null);
        $row_event = self::db_positive_int($row['event_id'] ?? null);
        $group = self::db_positive_int($row['group_id'] ?? null);
        $assigner = self::db_positive_int($row['assigned_by_user_id'] ?? null);
        $related_event = self::db_positive_int($row['related_event_id'] ?? null);
        $phone = $row['guest_phone'] ?? null;
        $normalized_phone = is_string($phone) && function_exists('pge_event_guests_norm_phone')
            ? pge_event_guests_norm_phone($phone)
            : null;
        if ($id === null || $row_event === null || $group === null || $assigner === null || $related_event === null
            || !is_string($phone) || $phone === '' || strlen($phone) > 32
            || !is_string($normalized_phone) || $normalized_phone !== $phone
            || !self::required_string($row['created_at'] ?? null)
            || !self::required_string($row['updated_at'] ?? null)) {
            return self::database_error();
        }
        if ($row_event !== $event_id || $related_event !== $event_id) return self::cross_event();
        return [
            'id' => $id,
            'event_id' => $row_event,
            'guest_phone' => $phone,
            'group_id' => $group,
            'assigned_by_user_id' => $assigner,
            'created_at' => $row['created_at'],
            'updated_at' => $row['updated_at'],
        ];
    }

    private static function normalize_audit($row, $event_id)
    {
        if (!is_array($row)) return self::database_error();
        foreach (['id', 'event_id', 'actor_user_id', 'action', 'entity_type', 'entity_id', 'metadata', 'created_at'] as $key) {
            if (!array_key_exists($key, $row)) return self::database_error();
        }
        $id = self::db_positive_int($row['id'] ?? null);
        $row_event = self::db_positive_int($row['event_id'] ?? null);
        $actor = self::db_positive_int($row['actor_user_id'] ?? null);
        $entity = ($row['entity_id'] ?? null) === null ? null : self::db_positive_int($row['entity_id']);
        if ($id === null || $row_event === null || $actor === null || (($row['entity_id'] ?? null) !== null && $entity === null)) {
            return self::database_error();
        }
        if ($row_event !== $event_id) return self::cross_event();
        if (!is_string($row['action'] ?? null) || !in_array($row['action'], self::AUDIT_ACTIONS, true)
            || !is_string($row['entity_type'] ?? null) || !in_array($row['entity_type'], self::AUDIT_ENTITY_TYPES, true)
            || !self::required_string($row['created_at'] ?? null)) {
            return self::database_error();
        }
        $metadata = null;
        if (($row['metadata'] ?? null) !== null) {
            if (!is_string($row['metadata'])) return self::database_error();
            $metadata = json_decode($row['metadata'], true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($metadata)) return self::database_error();
        }
        if (strpos($row['action'], 'guest_group_') === 0) {
            $metadata = self::normalize_guest_audit_metadata($row['action'], $metadata);
            if ($metadata instanceof WP_Error) return $metadata;
        }
        return [
            'id' => $id,
            'event_id' => $row_event,
            'actor_user_id' => $actor,
            'action' => $row['action'],
            'entity_type' => $row['entity_type'],
            'entity_id' => $entity,
            'metadata' => $metadata,
            'created_at' => $row['created_at'],
        ];
    }

    private static function normalize_guest_audit_metadata($action, $metadata)
    {
        $shapes = [
            'guest_group_assigned' => ['group_id'],
            'guest_group_moved' => ['previous_group_id', 'new_group_id'],
            'guest_group_unassigned' => ['previous_group_id'],
        ];
        $keys = $shapes[$action] ?? null;
        if ($keys === null || !is_array($metadata) || array_keys($metadata) !== $keys) return self::database_error();
        foreach ($keys as $key) if (!self::valid_id($metadata[$key])) return self::database_error();
        return $metadata;
    }

    private static function normalize_scoped_ids(array $rows, $event_id, $field)
    {
        $out = [];
        $seen = [];
        foreach ($rows as $row) {
            $row_event = self::db_positive_int($row['event_id'] ?? null);
            $related_event = self::db_positive_int($row['related_event_id'] ?? null);
            $id = self::db_positive_int($row[$field] ?? null);
            if ($row_event === null || $related_event === null || $id === null) return self::database_error();
            if ($row_event !== $event_id || $related_event !== $event_id) return self::cross_event();
            if (isset($seen[$id])) return self::database_error();
            $seen[$id] = true;
            $out[] = $id;
        }
        return $out;
    }

    private static function normalize_phone_input($value)
    {
        if (!is_string($value) || !function_exists('pge_event_guests_norm_phone')) return self::invalid_input();
        $phone = pge_event_guests_norm_phone($value);
        if (!is_string($phone) || $phone === '' || strlen($phone) > 32) return self::invalid_input();
        return $phone;
    }

    private static function db_positive_int($value)
    {
        $value = self::db_nonnegative_int($value);
        return $value !== null && $value > 0 ? $value : null;
    }

    private static function db_nonnegative_int($value)
    {
        if (is_int($value)) return $value >= 0 ? $value : null;
        if (!is_string($value) || preg_match('/\A(?:0|[1-9][0-9]*)\z/', $value) !== 1) return null;
        if (strlen($value) > strlen((string) PHP_INT_MAX)
            || (strlen($value) === strlen((string) PHP_INT_MAX) && strcmp($value, (string) PHP_INT_MAX) > 0)) {
            return null;
        }
        return (int) $value;
    }

    private static function valid_id($value)
    {
        return is_int($value) && $value > 0;
    }

    private static function valid_role($value)
    {
        return is_string($value) && in_array($value, self::MEMBERSHIP_ROLES, true);
    }

    private static function write_storage_error($error)
    {
        if (!($error instanceof WP_Error)) return self::database_error();
        return $error->get_error_code() === 'cross_event' ? self::database_error() : $error;
    }

    private static function require_current_guest($event_id, $phone)
    {
        if (!function_exists('pge_event_guests_resolve_current_by_phone')) return self::database_error();
        try {
            $result = pge_event_guests_resolve_current_by_phone($event_id, $phone);
        } catch (Throwable $e) {
            return self::database_error();
        }
        if (!is_array($result) || array_keys($result) !== ['status'] || !is_string($result['status'])) {
            return self::database_error();
        }
        if ($result['status'] === 'found') return true;
        if ($result['status'] === 'not_found') return self::not_found();
        if ($result['status'] === 'ambiguous') return self::ambiguous_guest();
        return self::database_error();
    }

    private static function require_user($user_id)
    {
        if (!function_exists('get_userdata')) return self::database_error();
        try {
            $user = get_userdata($user_id);
        } catch (Throwable $e) {
            return self::database_error();
        }
        return $user === false || $user === null ? self::not_found() : $user;
    }

    private static function only_filters(array $filters, array $allowed)
    {
        foreach (array_keys($filters) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) return false;
        }
        return true;
    }

    private static function is_list(array $values)
    {
        if ($values === []) return true;
        return array_keys($values) === range(0, count($values) - 1);
    }

    private static function required_string($value)
    {
        return is_string($value) && $value !== '';
    }

    private static function nullable_string($value)
    {
        return $value === null || is_string($value);
    }

    private static function string_length($value)
    {
        return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
    }

    private static function invalid_input()
    {
        return new WP_Error('invalid_input', 'Invalid repository input.');
    }

    private static function invalid_name()
    {
        return new WP_Error('invalid_name', 'Invalid invitation group name.');
    }

    private static function duplicate_group()
    {
        return new WP_Error('duplicate_group', 'An active invitation group with this identity already exists.');
    }

    private static function duplicate_membership()
    {
        return new WP_Error('duplicate_membership', 'An event host membership already exists.');
    }

    /**
     * H1C-W8 Fix Pass — the target group already has another active,
     * quota-enabled Additional Inviter. Deliberately reveals nothing about
     * WHICH membership/user holds it — only that the group's exclusivity
     * slot is occupied, which the caller (already Owner/Admin, already
     * operating on this specific group) is entitled to know without that
     * being an enumeration/privacy leak.
     */
    private static function quota_group_conflict()
    {
        return new WP_Error('quota_group_conflict', 'This group already has an active Additional Inviter.');
    }

    private static function invalid_state()
    {
        return new WP_Error('invalid_state', 'The event access record is not in a writable state.');
    }

    private static function concurrent_update()
    {
        return new WP_Error('concurrent_update', 'The event access record changed during the operation.');
    }

    private static function ambiguous_guest()
    {
        return new WP_Error('ambiguous_guest', 'The invited guest identity is ambiguous.');
    }

    private static function invalid_filter()
    {
        return new WP_Error('invalid_filter', 'Invalid repository filter.');
    }

    private static function not_found()
    {
        return new WP_Error('not_found', 'Requested event access record was not found.');
    }

    private static function cross_event()
    {
        return new WP_Error('cross_event', 'Event access record belongs to another event.');
    }

    private static function database_error()
    {
        return new WP_Error('database_error', 'Unable to access event access storage.');
    }
}

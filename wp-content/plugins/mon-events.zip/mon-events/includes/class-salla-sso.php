<?php
if (!defined('ABSPATH')) exit;

class Mon_Salla_SSO
{
    // استبدل هذه القيم بالقيم الحقيقية من لوحة مطوري سلة
    private $client_id     = '82febe64-c582-46d5-8dd2-c7938eddf2de';
    private $client_secret = '07ac5a341a0dcf57669205d05544ae61d9c5e4d64a5230d46c0ae85aebf95503';
    private $redirect_uri  = '';

    public function __construct()
    {
        $this->redirect_uri = home_url('/salla-callback-sso');
        add_action('init', [$this, 'handle_salla_response']);
    }

    /**
     * الخطوة 1: توليد الرابط لزر "الدخول بواسطة سلة"
     */
    public function get_login_url()
    {
        $url = "https://accounts.salla.sa/oauth2/auth";
        $params = [
            'client_id'     => $this->client_id,
            'redirect_uri'  => $this->redirect_uri,
            'response_type' => 'code',
            'scope'         => 'read_customers',
            'state'         => 'no_nonce_for_testing' // يفضل استخدام قيمة ثابتة في البداية للتأكد من الربط
        ];
        return add_query_arg($params, $url);
    }

    /**
     * الخطوة 2: معالجة العودة من سلة
     */
    public function handle_salla_response()
    {
        // التحقق من أننا في مسار العودة الصحيح
        if (isset($_GET['code']) && strpos($_SERVER['REQUEST_URI'], 'salla-callback-sso') !== false) {

            $access_token = $this->exchange_code_for_token($_GET['code']);

            if ($access_token) {
                $user_profile = $this->get_salla_user_profile($access_token);
                if ($user_profile) {
                    $this->login_or_create_user($user_profile);
                }
            } else {
                wp_die('خطأ في استبدال الكود بالتوكن. تأكد من إعدادات الـ Client Secret.');
            }
        }
    }

    /**
     * الخطوة 3: تبادل الكود بالتوكن (API Call)
     */
    private function exchange_code_for_token($code)
    {
        $response = wp_remote_post('https://accounts.salla.sa/oauth2/token', [
            'body' => [
                'grant_type'    => 'authorization_code',
                'client_id'     => $this->client_id,
                'client_secret' => $this->client_secret,
                'redirect_uri'  => $this->redirect_uri,
                'code'          => $code,
            ],
        ]);

        if (is_wp_error($response)) return false;

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['access_token'] ?? false;
    }

    /**
     * الخطوة 4: جلب بيانات الملف الشخصي من سلة
     */
    private function get_salla_user_profile($access_token)
    {
        $response = wp_remote_get('https://accounts.salla.sa/oauth2/user/info', [
            'headers' => [
                'Authorization' => 'Bearer ' . $access_token,
                'Accept'        => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) return false;

        $body = json_decode(wp_remote_retrieve_body($response), true);

        // سلة تعيد البيانات داخل كائن 'data'
        return $body['data'] ?? false;
    }

    /**
     * الخطوة 5: تسجيل الدخول أو إنشاء حساب
     */
    private function login_or_create_user($salla_user)
    {
        $email = $salla_user['email'];
        $user  = get_user_by('email', $email);

        if (!$user) {
            // إنشاء مستخدم جديد
            $random_password = wp_generate_password();
            $user_id = wp_create_user($email, $random_password, $email);

            if (is_wp_error($user_id)) {
                wp_die('تعذر إنشاء مستخدم جديد: ' . $user_id->get_error_message());
            }

            $user = get_user_by('id', $user_id);

            // تحديث الاسم والبيانات الإضافية
            wp_update_user([
                'ID'         => $user_id,
                'first_name' => $salla_user['first_name'] ?? '',
                'last_name'  => $salla_user['last_name'] ?? '',
                'display_name' => $salla_user['name'] ?? $email,
            ]);
        }

        // تخزين رقم الجوال دائماً للتأكد من تحديثه
        if (!empty($salla_user['mobile'])) {
            update_user_meta($user->ID, 'billing_phone', $salla_user['mobile']);
        }

        // تسجيل الدخول
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);

        // التوجيه لصفحة الحساب أو الرئيسية
        wp_redirect(home_url('/dashboard'));
        exit;
    }
}
new Mon_Salla_SSO();

/**
 * إضافة زر الدخول بواسطة سلة في صفحة الدخول
 */
add_action('login_form', function () {
    $sso = new Mon_Salla_SSO();
    $login_url = $sso->get_login_url();
?>
    <div style="margin-bottom: 20px; text-align: center;">
        <a href="<?php echo esc_url($login_url); ?>"
            style="display: block; background-color: #56d0b6; color: #fff; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: bold; border: 1px solid #45b19a;">
            <img src="https://salla.sa/favicon.ico" style="width:16px; vertical-align:middle; margin-left:8px;">
            الدخول السريع بواسطة سلة
        </a>
        <p style="margin-top:10px; font-size:11px; color:#777;">سيتم إنشاء حساب لك تلقائياً إذا كانت هذه زيارتك الأولى</p>
        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
    </div>
<?php
});

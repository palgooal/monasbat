<footer class="pg-main-footer">
    <p>جميع الحقوق محفوظة لشركة بال قول &copy; <?php echo date('Y'); ?></p>
</footer>
<?php wp_footer(); ?>
</body>

</html>